import 'package:crud_task/db_helper.dart';
import 'package:crud_task/edit_screen.dart';
import 'package:crud_task/user_model.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'add_screen.dart';
import 'db_handler.dart';

class ListScreen extends StatefulWidget {
  Function? getData;
  ListScreen({
    super.key,
    this.getData,
  });

  @override
  State<ListScreen> createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  TextEditingController searchController = TextEditingController();

  List<Map<String, dynamic>> taskList = [];
  List<Map<String, dynamic>> filterList = [];
  bool showNoDataText = false;
  Database? _database;
  //int count = 1;

  @override
  void initState() {
    getFromUser();
    super.initState();
  }

  Widget build(BuildContext context) {
    if (taskList == null) {
      taskList = <UserModel>[].cast<Map<String, dynamic>>();
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('List'),
      ),
      body: Column(
        children: [
          Text(
            "Data List",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
          ),
          SizedBox(
            height: 30,
          ),
          searBar(),
          SizedBox(
            height: 10,
          ),
          getListView(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AddScreen(
                  setData: (val) async {
                    await getFromUser();
                    setState(() {
                      filterList.clear();
                      searchController.clear();
                    });
                  },
                ),
              ));
        },
        tooltip: 'Add List',
        child: const Icon(Icons.add),
      ),
    );
  }

  Expanded getListView() {
    return Expanded(
      child: showNoDataText
          ? Text("data not found")
          : ListView.builder(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              itemCount:
                  filterList.isNotEmpty ? filterList.length : taskList.length,
              itemBuilder: (context, index) => Card(
                shape: RoundedRectangleBorder(
                  side: BorderSide(),
                  borderRadius: BorderRadius.circular(20.0), //<-- SEE HERE
                ),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: ListTile(
                    title: Text(filterList.isNotEmpty
                        ? filterList[index]['name']
                        : "${taskList[index]['name']}"),
                    trailing: Container(
                      width: 100,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                filterList.isNotEmpty
                                    ? deleteMethod(0, index)
                                    : deleteMethod(1, index);
                              },
                              icon: Icon(
                                Icons.delete,
                                color: Colors.red,
                              ),
                            ),
                          ),
                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                filterList.isNotEmpty
                                    ? updateUser(
                                        filterList[index]['id'],
                                        filterList[index]['name'],
                                      )
                                    : updateUser(
                                        taskList[index]['id'],
                                        taskList[index]['name'],
                                      );
                              },
                              icon: Icon(
                                Icons.edit,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  searBar() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextField(
        controller: searchController,
        onChanged: (value) {
          search(val: value);
        },
        keyboardType: TextInputType.name,
        textInputAction: TextInputAction.none,
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.search_rounded),
          hintText: 'search here',
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: BorderSide(width: 2, color: Colors.blueAccent),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: BorderSide(width: 2, color: Colors.blue),
          ),
        ),
      ),
    );
  }

  Future<Database?> openDB() async {
    _database = await DbHandler().openDB();
    return _database;
  }

  Future<void> getFromUser() async {
    _database = await openDB();
    DbHelper userRepo = new DbHelper();

    taskList = await userRepo.getUsers(_database);
    //await userRepo.getUsers(_database);

    await _database?.close();
    setState(() {});
  }

  Future<int?> deleteUser(int ids) async {
    _database = await openDB();
    return await _database?.rawDelete("DELETE FROM USER WHERE id=$ids");
  }

  void updateUser(int id, String name) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => EditScreen(
          ids: id,
          names: name,
          getData: (val) async {
            searchController.text = "";
            filterList.clear();
            await getFromUser();
            setState(() {});
          },
        ),
      ),
    );
  }

  deleteMethod(int wlist, int index) {
    if (wlist == 0) {
      deleteUser(filterList[index]['id']).whenComplete(() async {
        searchController.text = "";
        filterList.clear();
        await getFromUser();
        setState(() {});
      });
    } else {
      deleteUser(taskList[index]['id']).whenComplete(() async {
        searchController.text = "";
        filterList.clear();
        await getFromUser();
        setState(() {});
      });
    }
  }

  search({required String val}) {
    filterList.clear();
    filterList.addAll(taskList.where((element) =>
        element['name'].toLowerCase().contains(val.toLowerCase())));
    if (val.isNotEmpty && filterList.isEmpty) {
      showNoDataText = true;
      setState(() {});
    } else {
      showNoDataText = false;
      setState(() {});
    }
    setState(() {});
  }
}
