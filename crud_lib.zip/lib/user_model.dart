class UserModel {
  final String name;

  UserModel(this.name);

  Map<String, dynamic> toMap() {
    return {
      'name': name,
    };
  }
}
