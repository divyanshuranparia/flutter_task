import 'package:crud_task/user_model.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'db_handler.dart';
import 'db_helper.dart';

class AddScreen extends StatefulWidget {
  Function? setData;

  AddScreen({super.key, this.setData});

  @override
  State<AddScreen> createState() {
    return AddScreenState();
  }
}

class AddScreenState extends State<AddScreen> {
  TextEditingController textController = new TextEditingController();
  //TextEditingController numController = new TextEditingController();

  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Database? _database;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Screen"),
      ),
      body: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  TextField(
                    controller: textController,
                    decoration: InputDecoration(
                      hintText: 'Enter Text',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  // TextField(
                  //   controller: numController,
                  //   decoration: InputDecoration(
                  //     hintText: 'Enter Number',
                  //     border: OutlineInputBorder(
                  //       borderRadius: BorderRadius.circular(10),
                  //     ),
                  //   ),
                  //   keyboardType: TextInputType.number,
                  // ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);

                setState(() {
                  insertDB();
                });
                // widget.setData(textController.text);
                // Navigator.of(context).pop();
              },
              child: Text('Submit'),
            ),
            // ElevatedButton(
            //   onPressed: () {
            //     getFromUser();
            //     // widget.setData(textController.text);
            //     // Navigator.of(context).pop();
            //   },
            //   child: Text('View'),
            // )
          ],
        ),
      ),
    );
  }

  Future<Database?> openDB() async {
    _database = await DbHandler().openDB();
    return _database;
  }

  Future<void> insertDB() async {
    _database = await openDB();

    DbHelper userRepo = new DbHelper();

    userRepo.createTable(_database);

    UserModel userModel = new UserModel(
      textController.text.toString(),
    );

    await _database?.insert('USER', userModel.toMap());
    await _database?.close();
    if (widget.setData != null) {
      widget.setData!(true);
    }
  }

  // Future<void> getFromUser() async {
  //   _database = await openDB();
  //   DbHelper userRepo = new DbHelper();
  //
  //   await userRepo.getUsers(_database);
  //
  //   // await userRepo.getUsers(_database);
  //   await _database?.close();
  // }

}
