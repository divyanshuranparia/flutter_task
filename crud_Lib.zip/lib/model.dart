class Model {
  final int id;
  Model(this.id);
  Map<String, dynamic> toMap() {
    return {
      'id': id,
    };
  }
}
