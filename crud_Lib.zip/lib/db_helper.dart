import 'package:crud_task/model.dart';
import 'package:sqflite/sqflite.dart';

class DbHelper {
  get db => null;

  void createTable(Database? db) {
    db?.execute(
        'CREATE TABLE IF NOT EXISTS USER(id INTEGER PRIMARY KEY, name TEXT)');
  }

  // static Future<List<Map<String, dynamic>>> getUsers(Database? db) async {
  //   final List<Map<String, dynamic>> maps = await db!.query('USER');
  //   return maps;
  // }

  Future<List<Map<String, dynamic>>> getUsers(Database? db) async {
    final List<Map<String, dynamic>> maps = await db!.query('USER');
    return maps;
  }

  // Future<void> getUsers(Database? db) async {
  //   final List<Map<String, dynamic>> maps = await db!.query('USER');
  //   print(maps);
  // }
}
