import 'package:crud_task/user_model.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import 'db_handler.dart';
import 'db_helper.dart';

class EditScreen extends StatefulWidget {
  final int? ids;
  final String? names;
  Function? getData;

  EditScreen({
    super.key,
    this.ids,
    this.names,
    this.getData,
  });

  @override
  State<EditScreen> createState() => _EditScreenState();
}

class _EditScreenState extends State<EditScreen> {
  Database? _database;
  TextEditingController idController = new TextEditingController();
  TextEditingController textController = new TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    textController.text = widget.names!;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Screen"),
      ),
      body: Container(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Text(idController.text),
                  TextField(
                    controller: textController,
                    decoration: InputDecoration(
                      hintText: 'Enter Text',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  // TextField(
                  //   controller: numController,
                  //   decoration: InputDecoration(
                  //     hintText: 'Enter Number',
                  //     border: OutlineInputBorder(
                  //       borderRadius: BorderRadius.circular(10),
                  //     ),
                  //   ),
                  //   keyboardType: TextInputType.number,
                  // ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                update(widget.ids!);
                Navigator.of(context).pop();
              },
              child: Text('Submit'),
            ),
            // ElevatedButton(
            //   onPressed: () {
            //     getFromUser();
            //     // widget.getdata(textController.text);
            //     // Navigator.of(context).pop();
            //   },
            //   child: Text('View'),
            // )
          ],
        ),
      ),
    );
  }

  Future<Database?> openDB() async {
    _database = await DbHandler().openDB();
    return _database;
  }

  Future<void> update(int id) async {
    _database = await openDB();
    UserModel userModel = new UserModel(textController.text.toString());
    await _database?.update(
      "USER",
      userModel.toMap(),
      where: 'id=?',
      whereArgs: [id],
    );
    _database?.close();
    if (widget.getData != null) {
      widget.getData!(true);
    }
  }
  // Future update(newAge, id) async {
  //   var dbClient = await SqliteDB().db;
  //   var res = await dbClient.rawQuery(""" UPDATE User
  //       SET age = newAge WHERE id = '$id'; """);
  //   return res;
  // }
}
