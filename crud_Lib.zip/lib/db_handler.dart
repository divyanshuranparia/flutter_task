import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DbHandler {
  static final DbHandler _dbHandler = DbHandler._internal();
  static Database? _database;

  //database single instance
  factory DbHandler() {
    return _dbHandler;
  }
  DbHandler._internal();
  //method for open Database
  Future<Database?> openDB() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'user.db'),
    );

    return _database;
  }
}
