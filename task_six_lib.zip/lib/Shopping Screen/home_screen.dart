import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_six/widgets/colors.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);
  final img = [
    'assets/Images/banner.svg',
    'assets/Images/banner.svg',
    'assets/Images/banner.svg',
    'assets/Images/banner.svg',
    'assets/Images/banner.svg',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SvgPicture.asset('assets/Images/carrot.svg'),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset('assets/Images/location.svg'),
              Text("Rajkot,Gujarat"),
            ],
          ),
          // Note: Same code is applied for the TextFormField as well
          TextField(
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
                prefixIcon: SvgPicture.asset(
                  'assets/Icons/search.svg',
                  height: 18.21,
                  width: 18.21,
                  fit: BoxFit.scaleDown,
                ),
                prefixIconColor: AColor.black,
                hintText: 'Search store',
                hintStyle: TextStyle(color: AColor.SearchHint, fontSize: 14),
                border: InputBorder.none,
                filled: true,
                fillColor: AColor.HomeSearch,
                focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Colors.transparent), //<-- SEE HERE
                  borderRadius: BorderRadius.circular(50.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.transparent,
                  ),
                  borderRadius: BorderRadius.circular(50.0),
                )),
          ),
          Container(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemBuilder: (BuildContext cotext, int index) {
                  return Container(
                    child: SvgPicture.asset(
                      img[index],
                      height: 115,
                      width: 367,
                      fit: BoxFit.scaleDown,
                    ),
                  );
                },
              )),
        ],
      )),
    );
  }
}
