import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../widgets/colors.dart';
import '../widgets/image_files.dart';

class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  bool _isObscure = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Image.asset(
              ImageFiles.images.LogInBG,
              fit: BoxFit.fill,
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * 0.1),
                Align(
                  alignment: Alignment.center,
                  child:
                      SvgPicture.asset(ImageFiles.icons.carrotClr, height: 50),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.13,
                ),
                Text(
                  'Sign Up',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.015,
                ),
                Text(
                  'Enter your credentials to continue',
                  style: TextStyle(
                    fontSize: 16,
                    color: AColor.SearchHint,
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.05,
                ),
                Text(
                  'Username',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AColor.SearchHint,
                  ),
                ),
                TextFormField(
                  cursorColor: AColor.themeColor,
                  style: TextStyle(
                    fontSize: 18,
                  ),
                  decoration: InputDecoration(
                    hintText: 'enter username',
                    hintStyle: TextStyle(
                      fontSize: 15,
                      color: AColor.grey,
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.themeColor,
                      ),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.numberBorder,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.0375,
                ),
                Text(
                  'Email',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AColor.SearchHint,
                  ),
                ),
                TextFormField(
                  cursorColor: AColor.themeColor,
                  style: TextStyle(
                    fontSize: 18,
                  ),
                  decoration: InputDecoration(
                    hintText: 'enter email address',
                    hintStyle: TextStyle(
                      fontSize: 15,
                      color: AColor.grey,
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.themeColor,
                      ),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.numberBorder,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.0375,
                ),
                Text(
                  'Password',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AColor.SearchHint,
                  ),
                ),
                TextFormField(
                  obscureText: _isObscure,
                  keyboardType: TextInputType.number,
                  cursorColor: AColor.themeColor,
                  style: TextStyle(
                    fontSize: 18,
                  ),
                  decoration: InputDecoration(
                    hintText: 'enter password',
                    hintStyle: TextStyle(
                      fontSize: 15,
                      color: AColor.grey,
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.themeColor,
                      ),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        width: 1.5,
                        color: AColor.numberBorder,
                      ),
                    ),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          _isObscure = !_isObscure;
                        });
                      },
                      icon: SvgPicture.asset(
                        ImageFiles.icons.eye,
                        color: _isObscure ? AColor.SearchHint : AColor.black,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.02,
                ),
                Text(
                  'By continuing you agree to our Terms of Service and Privacy Policy.',
                  style: TextStyle(
                    letterSpacing: 0.5,
                    fontSize: 14,
                    color: AColor.forgot,
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.035,
                ),
                Center(
                  child: InkWell(
                    onTap: () {},
                    borderRadius: BorderRadius.circular(10),
                    splashColor: AColor.grey.withOpacity(0.3),
                    highlightColor: AColor.grey.withOpacity(0.3),
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.07,
                      width: MediaQuery.of(context).size.width * 0.85,
                      decoration: BoxDecoration(
                        color: AColor.themeColor,
                        borderRadius: BorderRadius.circular(19),
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Sing Up',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AColor.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.029,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Already have an account? ',
                      style: TextStyle(
                        letterSpacing: 1,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AColor.forgot,
                      ),
                    ),
                    Text(
                      'Singup',
                      style: TextStyle(
                        letterSpacing: 1.2,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AColor.themeColor,
                      ),
                    ),
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
