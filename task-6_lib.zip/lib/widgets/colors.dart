import 'package:flutter/material.dart';

class AColor {
  static const Color themeColor = Color(0XFF53B175);

  static const Color white = Color(0XFFFFFFFF);

  static const Color black = Color(0XFF000000);

  static const Color grey = Color(0XFF808080);

  static const Color HomeSearch = Color(0XFFF2F3F2);

  static const Color SearchHint = Color(0XFF7C7C7C);

  static const Color numberBorder = Color(0XFFE2E2E2);

  static const Color googlebut = Color(0XFF5383EC);

  static const Color facebookbut = Color(0XFF4A66AC);

  static const Color forgot = Color(0XFF181725);
}
