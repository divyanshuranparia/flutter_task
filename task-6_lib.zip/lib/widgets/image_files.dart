import 'package:flutter/material.dart';

class ImageFiles {
  static _Icons icons = _Icons();
  static _Images images = _Images();
}

class _Icons {
  final String splash = 'assets/Icons/splash.svg';
  final String carrot = 'assets/Icons/carrot.svg';
  final String carrotClr = 'assets/Icons/carrot_color.svg';
  final String google = 'assets/Icons/google.svg';
  final String facebook = 'assets/Icons/facebook.svg';
  final String eye = 'assets/Icons/eye.svg';
}

class _Images {
  final String onBoardBG = 'assets/Images/onBoardBG.png';
  final String SignBG = 'assets/Images/SignInBG.png';
  final String LogInBG = 'assets/Images/login.png';
}
