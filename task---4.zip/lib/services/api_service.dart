import 'dart:convert' as convert;
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;

import '../models/getResponse.dart';
import '../models/loginResponse.dart';
import '../utils/SharedPreferences/shared_preferences.dart';

class ApiService {
  // SignUp API
  Future<LoginResponse> apiPostSignUp(Map<String, dynamic> para) async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/userRegestration");
    var response = await http.post(url, body: para);
    print('after calling');
    if (response.statusCode == 200) {
      print('after 200 calling');
      final data = convert.jsonDecode(response.body);
      if (data['message'] == "user is already exists" || data['status'] == 0) {
        print("after throw :: ${data['message']} and ${data['status']}");
        throw "User is already exists";
      } else if (data['status'] == 0) {
        throw "Data is not uploaded status is 0";
      } else {
        LoginResponse responseModel = LoginResponse.fromJson(data);
        print(responseModel.toJson());
        return responseModel;
      }
    } else {
      throw 'fail to upload data';
    }
  }

  // Login API
  Future<LoginResponse> apiPostLogin(Map<String, dynamic> para) async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/userLogin");
    var response = await http.post(url, body: para);
    print('after calling');
    if (response.statusCode == 200) {
      print('after 200 calling');
      final data = convert.jsonDecode(response.body);
      if (data['message'] == "user not found" || data['status'] == 0) {
        print("after throw :: ${data['message']} and ${data['status']}");
        throw "User not found";
      } else if (data['status'] == '0') {
        throw "Data is not uploaded status is 0";
      } else {
        LoginResponse responseModel = LoginResponse.fromJson(data);
        print(responseModel.toJson());
        return responseModel;
      }
    } else {
      throw 'fail to upload data';
    }
  }

  // Login API
  Future<LoginResponse> editApi(Map<String, dynamic> para) async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/userProfileUpdate");
    var response = await http.post(url, body: para);
    print('after calling');
    if (response.statusCode == 200) {
      print('after 200 calling');
      final data = convert.jsonDecode(response.body);
      if (data['message'] == "user not found" || data['status'] == 0) {
        print("after throw :: ${data['message']} and ${data['status']}");
        throw "User not found";
      } else if (data['status'] == '0') {
        throw "Data is not uploaded status is 0";
      } else {
        LoginResponse responseModel = LoginResponse.fromJson(data);
        print(responseModel.toJson());
        return responseModel;
      }
    } else {
      throw 'fail to upload data';
    }
  }

  Future<DashBoardModal> fetchData() async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/getProduct");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      final data = convert.jsonDecode(response.body);
      print("Data get");
      DashBoardModal dashBoardModal = DashBoardModal.fromjson(data);
      print("Data assign to model");
      return dashBoardModal;
    } else {
      throw response.body;
    }
  }

  Future<dynamic> uploadFile(filePath, Map<String, dynamic> pera) async {
    try {
      String fileName = filePath.path.split('/').last;
      FormData formData = FormData.fromMap({
        "image": await MultipartFile.fromFile(filePath, filename: fileName)
      });
      Map<String, dynamic> data = {
        'first_name': pera['first_name'],
        'email': pera['email'],
        'profile_image': formData
      };
      print("Data in API :: $data");
      Response response = await Dio().put(
        "http://mrmodh11.pythonanywhere.com/userProfileUpdate",
        data: data,
        // options: Options(
        //     headers: <String, String>{
        //       'Authorization': 'Bearer $authToken',
        //     }
        // )
      );
      // var response =
      // await http.post(
      //     Uri.parse("http://mrmodh11.pythonanywhere.com/userProfileUpdate"),
      //     body: data,
      // );
      final res = convert.jsonDecode(response.data);
      print("Resss :: $res");

      return res;
    } on DioError catch (e) {
      return e.response;
    } catch (e) {}
  }
}
