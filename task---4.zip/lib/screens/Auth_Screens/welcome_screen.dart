import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../custom_widgets/button.dart';
import '../../utils/utils.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          body: Stack(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(ImageStorage.images.welcomeScreen),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                  child: Image.asset(
                ImageStorage.images.carrotWhite,
                height: 56.h,
                width: 48.w,
              )),
              SizedBox(
                height: 35.h,
              ),
              const Text(welcom, style: heading2),
              const Text(toOurStore, style: heading2),
              SizedBox(
                height: 5.h,
              ),
              Text(
                gerYourGroceriesInAsFastAsOneHour,
                style: heading4,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: 55.w, right: 55.w, bottom: 60.h, top: 40.h),
                child: AppButton(
                    onPressed: () {
                      Get.offAllNamed(RoutesClass.getSignInScreenRoute(),
                          arguments: '');
                    },
                    text: welcomeButton,
                    normalColor: ColorPalette.appColor,
                    height: 67.h),
              )
            ],
          )
        ],
      )),
    );
  }
}
