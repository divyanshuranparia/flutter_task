// ignore_for_file: no_leading_underscores_for_local_identifiers

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:get/get.dart';

import '../../services/api_service.dart';
import '../../utils/app_textfiled.dart';
import '../../utils/utils.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool isShow = false;
  bool isLoading = false;

  void errorWidget(title, err) {
    Get.snackbar(
      title,
      err == '' ? "Please checkout above fields" : err.toString(),
      colorText: Colors.white,
      backgroundColor: ColorPalette.dangerBgColor,
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.all(10),
      icon: const Icon(
        Icons.error,
        color: ColorPalette.dangerIconColor,
      ),
    );
  }

  //For sign in method
  userLogIn(String _email, String _password) async {
    final auth = FirebaseAuth.instance;
    print("enter");

    UserCredential credential;
    try {
      credential = await auth.signInWithEmailAndPassword(
          email: _email, password: _password);
      Get.snackbar(
        "Successfully enter.",
        'You enter successfully..',
        colorText: Colors.white,
        backgroundColor: ColorPalette.successBgColor,
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(10),
        icon: const Icon(
          Icons.event_available_sharp,
          color: ColorPalette.successIconColor,
        ),
      );
      isLogin(true);
      Get.offAllNamed(RoutesClass.getMainScreenRoute());
      print("exit");
    } catch (err) {
      // Fluttertoast.showToast(msg: err.toString());
      errorWidget("Some Thing is Wrong", err);
      print("Some Thing is Wrong $err");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 40,
              margin: EdgeInsets.only(top: 40.h),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(ImageStorage.images.loginSignupB),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.all(23.w),
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: isLoading
                  ? const Center(
                      child: Loader(),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        spacerV50,
                        spacerV50,
                        Center(
                            child:
                                Image.asset(ImageStorage.images.carrotColor)),
                        spacerV50,
                        const Text(
                          loging,
                          style: heading2_26_b,
                        ),
                        spacerV20,
                        Text(
                          enterYourEmailsAndPassword,
                          style: heading4_s,
                        ),
                        spacerV40,
                        Text(
                          email,
                          style: heading4_s,
                        ),
                        AppTextField(
                          onChanged: ((value) => {}),
                          hintText: 'Enter email id',
                          textEditingController: _emailController,
                          keyboardType: TextInputType.emailAddress,
                        ),
                        spacerV40,
                        Text(
                          password,
                          style: heading4_s,
                        ),
                        AppTextField(
                          onChanged: ((value) => {}),
                          hintText: 'Enter password',
                          textEditingController: _passwordController,
                          obscureText: isShow ? false : true,
                          keyboardType: TextInputType.name,
                          suffixIcon: Icon(Icons.remove_red_eye_outlined,
                              color: isShow
                                  ? ColorPalette.appColor
                                  : ColorPalette.black),
                          onPressed: () {
                            isShow = !isShow;
                            setState(() {});
                          },
                        ),
                        spacerV10,
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Text(
                            forgotPassword,
                            style: heading4_b_s,
                          ),
                        ),
                        spacerV30,
                        AppButton(
                          text: logIn,
                          onPressed: (() {
                            if ((_emailController.text.trim() == '') ||
                                _passwordController.text.trim().isEmpty) {
                              errorWidget("Field is not empty..", '');
                              print("Field is not empty..");
                            } else if ((!_emailController.text
                                .trim()
                                .contains("@gmail.com"))) {
                              errorWidget("Email:: is not valid", '');
                              print("Email:: is not valid");
                            } else if ((!(_passwordController.text
                                        .trim()
                                        .length >=
                                    6) ||
                                _passwordController.text.trim().isEmpty)) {
                              errorWidget("Password:: is not valid!!", '');

                              print("Password:: is not valid!!");
                            } else {
                              // userLogIn(_emailController.text.trim(),
                              //     _passwordController.text.trim());
                              // errorWidget("Successfully enter.", '');
                              setState(() {
                                isLoading = true;
                              });

                              var apiService = ApiService();
                              try {
                                print("API calll..");
                                apiService.apiPostLogin({
                                  'email': _emailController.text.trim(),
                                  'password': _passwordController.text.trim(),
                                }).then((value) async {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  Get.snackbar("Success", 'Login successfully',
                                      snackPosition: SnackPosition.BOTTOM);
                                  print("${value.user}");
                                  print("Successfully enter.");
                                  storeUserData(value,true);

                                  Get.offAllNamed(
                                      RoutesClass.getMainScreenRoute());
                                }).catchError((error) {
                                  Get.snackbar("$error", '$error',
                                      snackPosition: SnackPosition.BOTTOM);
                                  setState(() {
                                    isLoading = false;
                                  });
                                });
                              } catch (e) {
                                Get.snackbar("Error", '$e',
                                    snackPosition: SnackPosition.BOTTOM);
                                setState(() {
                                  isLoading = false;
                                });
                              }
                              print("Successfully enter.");
                            }
                          }),
                          normalColor: ColorPalette.appColor,
                        ),
                        spacerV30,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              dontHaveAnAccount,
                              style: heading4_b_s,
                            ),
                            InkWell(
                              splashColor: ColorPalette.appColor,
                              onTap: () {
                                Get.toNamed(RoutesClass.getSignUpScreenRoute());
                              },
                              child: Text(
                                ' $singUp',
                                style: heading4_b_s.copyWith(
                                    color: ColorPalette.appColor),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
            )
          ],
        ),
      ),
    );
  }
}
