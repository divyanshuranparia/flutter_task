import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../utils/app_textfiled.dart';
import '../../utils/utils.dart';

class SignInScreen extends StatefulWidget {
  const SignInScreen({Key? key}) : super(key: key);

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final TextEditingController _number = TextEditingController();

  Widget textField() {
    return IntlPhoneField(
      style: heading2_18_b,
      showDropdownIcon: false,
      keyboardType: TextInputType.number,
      initialCountryCode:'+91',
      
      cursorColor: ColorPalette.black,
      dropdownTextStyle: heading2_18_b,
      decoration: InputDecoration(
        border: inputBorder,
        focusedBorder: inputBorder,
        enabledBorder: inputBorder,
        errorBorder: inputBorder,
        disabledBorder: inputBorder,

        contentPadding: EdgeInsets.only(top: 15.h, bottom: 15.h),
        focusedErrorBorder:
            inputBorder.copyWith(borderSide: BorderSide(color: Colors.orange)),
        // hintText: hintText ?? 'Enter Details',
        errorStyle: TextStyle(color: Colors.orange, fontSize: 14.sp),
      ),
      disableLengthCheck: true,
      onChanged: (phone) {
        print(phone.completeNumber);
      },
      onCountryChanged: (country) {
        print('Country changed to: ' + country.name);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            spacerV5,
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 380.h,
                child: FadeInImage(
                  fadeInDuration: const Duration(milliseconds: 50),
                  image: AssetImage(
                    ImageStorage.images.numberScreen,
                  ),
                  fit: BoxFit.fill,
                  placeholder: AssetImage(ImageStorage.images.numberScreen),
                )
                //   Image.asset(
                // ImageStorage.images.numberScreen,
                // fit: BoxFit.fill,
                //   ),
                ),
            spacerV20,
            spacer5,
            Container(
              // color: Colors.amber,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.symmetric(horizontal: 21.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    getYourgroceries,
                    style: heading2_26_b,
                  ),
                  spacerV5,
                  const Text(
                    withNectar,
                    style: heading2_26_b,
                  ),
                  spacerV10,
                  spacerV5,
                  textField(),
                  spacerV50,
                  Center(
                    child: Text(
                      orConnectWithSocialMedia,
                      style: heading4,
                    ),
                  ),
                  spacerV50,
                  AppButton(
                    text: continueWithGoogle,
                    onPressed: () {
                      Get.toNamed(RoutesClass.getLoginScreenRoute());
                    },
                    normalColor: ColorPalette.lightblue,
                    image: ImageStorage.images.google,
                  ),spacerV20,
                  AppButton(
                    text: continuewithFacebook,
                    onPressed: () {},
                    normalColor: ColorPalette.dartblue,
                    image: ImageStorage.images.facebook,
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  InputBorder get inputBorder => const UnderlineInputBorder(
      borderSide: BorderSide(color: ColorPalette.lightGrey, width: 1));
}
