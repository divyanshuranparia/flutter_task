import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:four_d_app/models/loginResponse.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

// import 'package:firebase_core/firebase_core.dart';
import '../../services/api_service.dart';
import '../../utils/app_textfiled.dart';
import '../../utils/utils.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _userName = TextEditingController();
  bool isLoading = false;

  // final FirebaseAuth _auth = FirebaseAuth.instance;

  late bool _sucess;
  late String _userEmail;

  void errorWidget(title, err) {
    Get.snackbar(
      title,
      err == '' ? "Please checkout above fields" : err.toString(),
      colorText: Colors.white,
      backgroundColor: ColorPalette.dangerBgColor,
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.all(10),
      icon: const Icon(
        Icons.error,
        color: ColorPalette.dangerIconColor,
      ),
    );
  }

  //For sign up method
  submitform(String _email, String _password) async {
    final auth = FirebaseAuth.instance;
    print("enter");

    UserCredential credential;
    try {
      credential = await auth.createUserWithEmailAndPassword(
          email: _email, password: _password);
      String uid = credential.user!.uid;
      Get.snackbar(
        "Successfully SignUp.",
        'Your mail id is successfully added..',
        colorText: Colors.white,
        backgroundColor: ColorPalette.successBgColor,
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(10),
        icon: const Icon(
          Icons.event_available_sharp,
          color: ColorPalette.successIconColor,
        ),
      );
      Get.offAllNamed(RoutesClass.getLoginScreenRoute());
      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .set({'UID': uid, 'email': _email, 'password': _password});

      print("exit");
    } catch (err) {
      errorWidget("Some Thing is Wrong", err);
      print("Some Thing is Wrong $err");
    }
  }

  bool isShow = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading == true
          ? const Center(child: Loader())
          : SingleChildScrollView(
              child: Stack(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height - 40,
                    margin: EdgeInsets.only(top: 40.h),
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(ImageStorage.images.loginSignupB),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.all(23.w),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        spacerV50,
                        spacerV30,
                        Center(
                            child:
                                Image.asset(ImageStorage.images.carrotColor)),
                        spacerV40,
                        Text(
                          singUp,
                          style: heading2_26_b,
                        ),
                        spacerV20,
                        Text(
                          enterYourCredentialsToContinue,
                          style: heading4_s,
                        ),
                        spacerV30,
                        Text(
                          userName,
                          style: heading4_s,
                        ),
                        AppTextField(
                          onChanged: ((value) => {}),
                          hintText: userName,
                          textEditingController: _userName,
                          keyboardType: TextInputType.name,
                        ),
                        spacerV30,
                        Text(
                          email,
                          style: heading4_s,
                        ),
                        AppTextField(
                          onChanged: ((value) => {}),
                          hintText: 'Enter email id',
                          keyboardType: TextInputType.emailAddress,
                          textEditingController: _emailController,
                          suffixIcon: Icon(
                            Icons.check,
                            color: ColorPalette.appColor,
                          ),
                        ),
                        spacerV30,
                        Text(
                          password,
                          style: heading4_s,
                        ),
                        AppTextField(
                          onChanged: ((value) => {}),
                          hintText: 'Enter password',
                          obscureText: isShow ? false : true,
                          keyboardType: TextInputType.name,
                          textEditingController: _passwordController,
                          suffixIcon: Icon(Icons.remove_red_eye_outlined,
                              color: isShow
                                  ? ColorPalette.appColor
                                  : ColorPalette.black),
                          onPressed: () {
                            isShow = !isShow;
                            setState(() {});
                          },
                        ),
                        spacerV20,
                        Row(
                          children: [
                            Text(
                              byContinuingYouAgreeToOur,
                              style: heading4.copyWith(
                                  letterSpacing: 1.1,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              " $termsOfService",
                              style: heading4.copyWith(
                                  color: ColorPalette.appColor,
                                  letterSpacing: 1.1,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text(
                              and,
                              style: heading4.copyWith(
                                  letterSpacing: 1.1,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              " $privacyPolicy",
                              style: heading4.copyWith(
                                  color: ColorPalette.appColor,
                                  letterSpacing: 1.1,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                        spacerV30,
                        AppButton(
                          text: singUp,
                          onPressed: (() {
                            if ((_emailController.text.trim() == '') ||
                                _passwordController.text.trim().isEmpty) {
                              errorWidget("Field is not empty..", '');
                              print("Field is not empty..");
                            } else if ((!_emailController.text
                                .trim()
                                .contains("@gmail.com"))) {
                              errorWidget("Email:: is not valid", '');
                              print("Email:: is not valid");
                            } else if ((!(_passwordController.text
                                        .trim()
                                        .length >=
                                    6) ||
                                _passwordController.text.trim().isEmpty)) {
                              errorWidget(
                                  "Password:: should be gretter than six latter",
                                  '');
                              print("Password:: is not valid!!");
                            } else if (_userName.text.trim().isEmpty) {
                              errorWidget("UserName:: is not empty!!", '');
                              print("UserName:: is not valid!!");
                            } else {
                              // submitform(_emailController.text.trim(),
                              //     _passwordController.text.trim());
                              setState(() {
                                isLoading = true;
                              });

                              var apiService = ApiService();
                              try {
                                print("API calll..");
                                apiService.apiPostSignUp({
                                  'first_name': _userName.text.trim(),
                                  'last_name': 'name',
                                  'email': _emailController.text.trim(),
                                  'password': _passwordController.text.trim(),
                                  'profile_image': ''
                                }).then((value) async {
                                  setState(() {
                                    isLoading = false;
                                  });
                                  Get.snackbar("Success", 'SignUp successfully',
                                      snackPosition: SnackPosition.BOTTOM);
                                  print("${value.user}");
                                  print("Successfully enter.");
                                  storeUserData(value, true);

                                  Get.offAllNamed(
                                      RoutesClass.getMainScreenRoute());
                                }).catchError((error) {
                                  Get.snackbar("$error", '$error',
                                      snackPosition: SnackPosition.BOTTOM);
                                  setState(() {
                                    isLoading = false;
                                  });
                                });
                              } catch (e) {
                                Get.snackbar("Error", '$e',
                                    snackPosition: SnackPosition.BOTTOM);
                                setState(() {
                                  isLoading = false;
                                });
                              }
                            }
                          }),
                          normalColor: ColorPalette.appColor,
                        ),
                        spacerV30,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              alreadyHaveAnAccount,
                              style: heading4_b_s,
                            ),
                            InkWell(
                              onTap: () {
                                Get.back();
                              },
                              child: Text(
                                ' $loging',
                                style: heading4_b_s.copyWith(
                                    color: ColorPalette.appColor),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
    );
  }
}
