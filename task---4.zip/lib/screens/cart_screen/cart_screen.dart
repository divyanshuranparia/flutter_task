import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:four_d_app/models/product_model/product_model.dart';
import 'package:four_d_app/utils/constants/textstyles.dart';
import 'package:four_d_app/utils/theme/color_palette.dart';
import 'package:four_d_app/utils/utils.dart';

import '../../custom_widgets/bottom_sheet.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Padding(
          padding: EdgeInsets.only(top: 5),
          child: Text(
            "My Cart",
            style: heading2_20_b,
          ),
        ),
        backgroundColor: ColorPalette.white,
        elevation: 1.5,
      ),
      body: Stack(
        children: [
          Container(
            padding: EdgeInsets.all(18),
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
                itemCount: productList.length,
                itemBuilder: (context, index) => Column(
                      children: [
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 70.h,
                                    width: 70.h,
                                    child: Image.asset(productList[index].img)),
                                spacerH30,
                                Expanded(
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                productList[index].name,
                                                overflow: TextOverflow.ellipsis,
                                                style: heading2_18_b.copyWith(
                                                    fontWeight: FontWeight.w800,
                                                    fontSize: 18),
                                              ),
                                              spacerV5,
                                              Text(productList[index].dis,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: heading2.copyWith(
                                                      color:
                                                          ColorPalette.textgrey,
                                                      fontSize: 15,
                                                      fontWeight:
                                                          FontWeight.bold))
                                            ],
                                          ),
                                          IconButton(
                                              onPressed: () {},
                                              icon: Icon(
                                                Icons.close,
                                                color: ColorPalette.textgrey,
                                              ))
                                        ],
                                      ),
                                      spacerV10,
                                      counterWidget(productList[index]),
                                    ],
                                  ),
                                ),
                              ]),
                        ),
                        Divider(
                          thickness: 1.5,
                        )
                      ],
                    )),
          ),
          Positioned(
              bottom: 20.h,
              right: 0,
              left: 0,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 18),
                child: AppButton(
                    normalColor: ColorPalette.appColor,
                    text: goToCheckout,
                    isPrice: true,
                    onPressed: () async{
                     BottomSheetHotel.bottomSheetHotel(context);
                    }),
              ))
        ],
      ),
    );
  }

  Widget counterWidget(argu) {
    int counter = 1;
    return StatefulBuilder(
      
        builder: (context, setState) => Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    InkWell(
                      splashColor: ColorPalette.appColor,
                      onTap: () {
                        setState(() {
                          if (counter > 1) {
                            counter--;
                          }
                        });
                      },
                      child: Icon(
                        Icons.remove,
                        size: 22,
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10.w),
                      width: 40.w,
                      height: 40.w,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: ColorPalette.borderColor,
                            width: 2.5.w,
                          ),
                          borderRadius: BorderRadius.circular(10.r)),
                      child: Center(
                          child: Text(
                        counter.toString(),
                        style: heading2_18_b.copyWith(
                            fontWeight: FontWeight.w800, fontSize: 18),
                      )),
                    ),
                    InkWell(
                      splashColor: ColorPalette.appColor,
                      onTap: () {
                        setState(() {
                          counter++;
                        });
                      },
                      child: Icon(
                        Icons.add,
                        size: 25,
                        color: ColorPalette.appColor,
                      ),
                    ),
                  ],
                ),
                Text(
                  argu.price,
                  style: heading2_18_b.copyWith(
                      fontWeight: FontWeight.w800, fontSize: 18),
                ),
              ],
            ));
  }
}
