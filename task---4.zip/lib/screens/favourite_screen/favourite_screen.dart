import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import '../../custom_widgets/button.dart';
import '../../models/product_model/product_model.dart';
import '../../utils/utils.dart';

class FavouriteScreen extends StatefulWidget {
  const FavouriteScreen({Key? key}) : super(key: key);

  @override
  State<FavouriteScreen> createState() => _FavouriteScreenState();
}

class _FavouriteScreenState extends State<FavouriteScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Padding(
          padding: EdgeInsets.only(top: 5),
          child: Text(
            "Favorurite",
            style: heading2_26_b,
          ),
        ),
        backgroundColor: ColorPalette.white,
        elevation: 1.5,
      ),
      body: Stack(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
                itemCount: coldDrink.length,
                itemBuilder: (context, index) => Column(
                      children: [
                        Container(
                          padding: EdgeInsets.all(15),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                SizedBox(
                                    height: 80.h,
                                    width: 80.h,
                                    child: Image.asset(coldDrink[index].img)),
                                spacerH30,
                                Expanded(
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              coldDrink[index].name,
                                              overflow: TextOverflow.ellipsis,
                                              style: heading2_18_b.copyWith(
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: 18),
                                            ),
                                            spacerV5,
                                            Text(coldDrink[index].dis,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                                style: heading2.copyWith(
                                                    color:
                                                        ColorPalette.textgrey,
                                                    fontSize: 15,
                                                    fontWeight:
                                                        FontWeight.bold))
                                          ],
                                        ),
                                      ),
                                      spacerH5,
                                      Row(children: [ Text("${coldDrink[index].price}",
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: heading2.copyWith(
                                                      color:
                                                          ColorPalette.textgrey,
                                                      fontSize: 15,
                                                      fontWeight:
                                                          FontWeight.bold)),
                                  Icon(
                                                Icons.arrow_forward_ios_outlined,
                                                color: ColorPalette.textgrey,
                                              )],)
                                    
                                    ],
                                  ),
                                ),
                              ]),
                        ),
                        Divider(
                          thickness: 1.5,
                        )
                      ],
                    )),
          ),
          Positioned(
              bottom: 20.h,
              right: 0,
              left: 0,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 18),
                child: AppButton(
                    normalColor: ColorPalette.appColor,
                    text: addAllToCart,
                   
                    onPressed: () {}),
              ))
        ],
      ),
    );
  }

  
}