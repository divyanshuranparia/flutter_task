import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:four_d_app/models/product_model/product_model.dart';
import 'package:get/get.dart';

import '../../custom_widgets/product_dis_image.dart';
import '../../models/getResponse.dart';
import '../../utils/utils.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({Key? key}) : super(key: key);

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  Product argu = Get.arguments;
  bool isLike = false;
  int counter = 1;
  bool isDetailShow = false;
  String baseUrl = 'http://mrmodh11.pythonanywhere.com';

  @override
  Widget build(BuildContext context) {
    print("image:::${argu.product_images![0].image}");
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height + 100,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            children: [
              const ProductDetailImage(),
              spacerV10,
              nameheartWidget(),
              counterWidget(),
              spacerV10,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: const Divider(
                  thickness: 1.3,
                ),
              ),
              spacerV10,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      productDetail,
                      style: heading2_18_b.copyWith(
                          fontWeight: FontWeight.w500, fontSize: 18),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          isDetailShow = !isDetailShow;
                        });
                      },
                      child: Icon(
                        isDetailShow != true
                            ? Icons.keyboard_arrow_right_sharp
                            : Icons.keyboard_arrow_down_outlined,
                        size: 28,
                        color: ColorPalette.black,
                      ),
                    ),
                  ],
                ),
              ),
              spacerV10,
              spacerV5,
              isDetailShow != true
                  ? SizedBox()
                  : Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Text(
                        longDis,
                        style: heading4.copyWith(
                            fontWeight: FontWeight.w500, fontSize: 16),
                      ),
                    ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: const Divider(
                  thickness: 1.3,
                ),
              ),
              spacerV10,
              spacerV5,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  children: [
                    Text(
                      nutritions,
                      style: heading2_18_b.copyWith(
                          fontWeight: FontWeight.w500, fontSize: 18),
                    ),
                    Spacer(),
                    Container(
                      padding: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                          color: ColorPalette.boxGrey,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        "100gr",
                        style: heading4,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          isDetailShow = !isDetailShow;
                        });
                      },
                      child: Icon(
                        isDetailShow != true
                            ? Icons.keyboard_arrow_right_sharp
                            : Icons.keyboard_arrow_down_outlined,
                        size: 28,
                        color: ColorPalette.black,
                      ),
                    ),
                  ],
                ),
              ),
              spacerV10,
              spacerV5,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: const Divider(
                  thickness: 1.3,
                ),
              ),
              spacerV10,
              spacerV5,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  children: [
                    Text(
                      review,
                      style: heading2_18_b.copyWith(
                          fontWeight: FontWeight.w500, fontSize: 18),
                    ),
                    const Spacer(),
                    RatingBar.builder(
                      initialRating: 2,
                      minRating: 1, itemSize: 20,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 5,
                      // ignore: prefer_const_constructors
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: Color(0xffF3603F),
                        size: 10,
                      ),
                      onRatingUpdate: (rating) {
                        print(rating);
                      },
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          isDetailShow = !isDetailShow;
                        });
                      },
                      child: Icon(
                        isDetailShow != true
                            ? Icons.keyboard_arrow_right_sharp
                            : Icons.keyboard_arrow_down_outlined,
                        size: 28,
                        color: ColorPalette.black,
                      ),
                    ),
                  ],
                ),
              ),
              spacerV20,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: AppButton(
                    normalColor: ColorPalette.appColor,
                    text: addToBasket,
                    onPressed: () {}),
              )
            ],
          ),
        ),
      ),
    );
  }

  // counter and price
  Widget counterWidget() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              InkWell(
                splashColor: ColorPalette.appColor,
                onTap: () {
                  setState(() {
                    if (counter > 1) {
                      counter--;
                    }
                  });
                },
                child: Icon(
                  Icons.remove,
                  size: 28,
                ),
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 10.w),
                width: 50.w,
                height: 50.w,
                decoration: BoxDecoration(
                    border: Border.all(
                      color: ColorPalette.borderColor,
                      width: 2.5.w,
                    ),
                    borderRadius: BorderRadius.circular(20.r)),
                child: Center(
                    child: Text(
                  counter.toString(),
                  style: heading2_18_b.copyWith(
                      fontWeight: FontWeight.w800, fontSize: 18),
                )),
              ),
              InkWell(
                splashColor: ColorPalette.appColor,
                onTap: () {
                  setState(() {
                    counter++;
                  });
                },
                child: Icon(
                  Icons.add,
                  size: 28,
                  color: ColorPalette.appColor,
                ),
              ),
            ],
          ),
          Text(
            argu.product_discount_price.toString(),
            style: heading2_18_b.copyWith(
                fontWeight: FontWeight.w800, fontSize: 21),
          ),
        ],
      ),
    );
  }

  //name and heart
  Widget nameheartWidget() {
    return Padding(
      padding: EdgeInsets.all(20.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                argu.product_name.toString(),
                style: heading2_18_b.copyWith(
                    fontWeight: FontWeight.w800, fontSize: 21),
              ),
              spacerV5,
              Text(argu.product_dic.toString(),
                  style: heading2.copyWith(
                      color: ColorPalette.textgrey,
                      fontSize: 15,
                      fontWeight: FontWeight.bold))
            ],
          ),
          IconButton(
              splashColor: ColorPalette.dangerBgColor,
              onPressed: () {
                setState(() {
                  isLike = !isLike;
                });
              },
              icon: isLike
                  ? Icon(
                      CupertinoIcons.heart_fill,
                      color: ColorPalette.dangerBgColor,
                      size: 28,
                    )
                  : Icon(
                      CupertinoIcons.heart,
                      size: 28,
                    ))
        ],
      ),
    );
  }
}
