import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:four_d_app/utils/utils.dart';
import 'package:get/get.dart';

import '../../custom_widgets/button.dart';
import '../../custom_widgets/profile_tile.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({Key? key}) : super(key: key);

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  List<Shared> data = [];
  String url =
      'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlcnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60';

  @override
  void initState() {
    getUserData();
    // TODO: implement initState
    super.initState();
  }

  getUserData() async {
    data = await fetchData();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: data.isEmpty
          ? const Center(
              child: Loader(),
            )
          : SizedBox(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: SingleChildScrollView(
                child: Column(children: [
                  spacerV50,
                  spacerV40,
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20.r),
                          child: SizedBox(
                            height: 70.w,
                            width: 70.w,
                            child:  CachedNetworkImage(
                                    imageUrl:url,
                                    placeholder: (context, url) =>
                                        Image.asset(ImageStorage.images.profile),
                                    errorWidget: (context, url, error) =>
                                        Image.asset(ImageStorage.images.profile),
                                  ),
                          ),
                        ),
                        spacerH20,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  data[0].first_name.toString(),
                                  style: heading1.copyWith(
                                      color: ColorPalette.black, fontSize: 18),
                                ),
                                spacerH10,
                                GestureDetector(
                                  onTap: () {
                                    Get.toNamed(
                                        RoutesClass.getEditProfileScreenRoute(),
                                        arguments: data[0]);
                                  },
                                  child: SvgPicture.asset(

                                    ImageStorage.icons.edit,
                                    color: ColorPalette.appColor,
                                    width: 18.w,
                                    height: 18.w,
                                  ),
                                ),
                              ],
                            ),
                            spacerV5,
                            Text(
                              data[0].email.toString(),
                              style: heading4.copyWith(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1.2),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  spacerV20,
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.order,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: orders,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.detail,
                        color: ColorPalette.black,
                        width: 18.w,
                        height: 18.w,
                      ),
                      title: myDetails,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.location,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: deliveryAddress,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.payment,
                        color: ColorPalette.black,
                        width: 18.w,
                        height: 18.w,
                      ),
                      title: paymentMethods,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.promoCode,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: promoCode,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.noti,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: notifecations,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.help,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: help,
                      betch: true),
                  const Divider(
                    thickness: 1.3,
                  ),
                  ProfileTile(
                      icon: SvgPicture.asset(
                        ImageStorage.icons.about,
                        color: ColorPalette.black,
                        width: 20.w,
                        height: 20.w,
                      ),
                      title: about,
                      betch: true),
                  spacerV40,
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 22),
                    child: AppButton(
                      text: backToHome,
                      textColor: ColorPalette.appColor,
                      icon: Icons.logout,
                      iconColor: ColorPalette.appColor,
                      iconSize: true,
                      onPressed: () {
                        // FirebaseAuth.instance.signOut();
                        removeLogin();
                        Get.offAllNamed(RoutesClass.getLoginScreenRoute());
                      },
                      normalColor: Colors.transparent,
                    ),
                  ),
                  spacerV20
                ]),
              ),
            ),
    );
  }
}
