import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import '../../custom_widgets/button.dart';
import '../../services/api_service.dart';
import '../../utils/app_textfiled.dart';
import '../../utils/utils.dart';
import 'dart:convert' as convert;

import 'package:http/http.dart' as http;

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _userName = TextEditingController();
  bool isLoading = false;
  String url =
      'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlcnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60';

  // final FirebaseAuth _auth = FirebaseAuth.instance;
  bool isShow = false;
  late bool _sucess;
  late String _userEmail;
  Shared data = Get.arguments;

  void errorWidget(title, err) {
    Get.snackbar(
      title,
      err == '' ? "Please checkout above fields" : err.toString(),
      colorText: Colors.white,
      backgroundColor: ColorPalette.dangerBgColor,
      snackPosition: SnackPosition.BOTTOM,
      margin: EdgeInsets.all(10),
      icon: const Icon(
        Icons.error,
        color: ColorPalette.dangerIconColor,
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _userName.text = data.first_name.toString();
    _emailController.text = data.email.toString();
  }

  File? image;
  final _picker = ImagePicker();
  bool showSpinner = false;

  Future getImage() async {
    final pickedFile =
        await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);

    if (pickedFile != null) {
      image = File(pickedFile.path);
      setState(() {});
      uploadImage();
    } else {
      print('no image selected');
    }
  }

  Future<void> uploadImage() async {
    var stream = http.ByteStream(image!.openRead());
    stream.cast();

    var length = await image!.length();

    var uri = Uri.parse('http://mrmodh11.pythonanywhere.com/userProfileUpdate');

    var request = http.MultipartRequest('POST', uri);

    request.fields['id'] = data.id!;
    // request.fields['first_name'] = data.first_name!;
    // request.fields['last_name'] = 'name';
    // request.fields['email'] = data.email!;

    print('ID :: ${data.id}');

    var multiport = http.MultipartFile('profile_image', stream, length,
        filename: image.toString());
    request.fields['profile_image'] = multiport.filename.toString();
    // request.files.add(multiport);

    var response = await request.send();

    print(response.stream.toString());
    if (response.statusCode == 200) {
      var res = await response.stream.bytesToString();
      print("data::${convert.jsonDecode(res)}");
      print('image uploaded :: ${multiport.filename.toString()}');
    } else {
      print('failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    print("data :: ${data}");
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(23.w),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height -
              AppBar().preferredSize.height,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: () {
                    // getImage();
                    // uploadImage();
                    getImage();
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.r),
                    child: SizedBox(
                      height: 150.w,
                      width: 150.w,
                      child: image == null
                          ? CachedNetworkImage(
                              imageUrl: url,
                              placeholder: (context, url) =>
                                  Image.asset(ImageStorage.images.profile),
                              errorWidget: (context, url, error) =>
                                  Image.asset(ImageStorage.images.profile),
                            )
                          : Image.file(
                              File(image!.path).absolute,
                              height: 100,
                              width: 100,
                              fit: BoxFit.cover,
                            ),
                    ),
                  ),
                ),
              ),
              spacerV50,
              Text(
                userName,
                style: heading4_s,
              ),
              AppTextField(
                onChanged: ((value) => {}),
                hintText: userName,
                textEditingController: _userName,
                keyboardType: TextInputType.name,
              ),
              spacerV50,
              Text(
                email,
                style: heading4_s,
              ),
              AppTextField(
                onChanged: ((value) => {}),
                hintText: 'Enter email id',
                keyboardType: TextInputType.emailAddress,
                textEditingController: _emailController,
                suffixIcon: Icon(
                  Icons.check,
                  color: ColorPalette.appColor,
                ),
              ),
              // AppButton(
              //     text: 'text',
              //     onPressed: () {
              //       onUploadImage();
              //     }),
              Spacer(),
              AppButton(
                text: "Update",
                onPressed: (() {
                  if ((_emailController.text.trim() == '') ||
                      _passwordController.text.trim().isEmpty) {
                    errorWidget("Field is not empty..", '');
                    print("Field is not empty..");
                  } else if ((!_emailController.text
                      .trim()
                      .contains("@gmail.com"))) {
                    errorWidget("Email:: is not valid", '');
                    print("Email:: is not valid");
                  } else if ((!(_passwordController.text.trim().length >= 6) ||
                      _passwordController.text.trim().isEmpty)) {
                    errorWidget(
                        "Password:: should be gretter than six latter", '');
                    print("Password:: is not valid!!");
                  } else if (_userName.text.trim().isEmpty) {
                    errorWidget("UserName:: is not empty!!", '');
                    print("UserName:: is not valid!!");
                  } else {
                    // submitform(_emailController.text.trim(),
                    //     _passwordController.text.trim());
                    setState(() {
                      isLoading = true;
                    });

                    var apiService = ApiService();
                    try {
                      print("API calll..");
                      apiService.apiPostSignUp({
                        'first_name': _userName.text.trim(),
                        'last_name': 'name',
                        'email': _emailController.text.trim(),
                        'password': _passwordController.text.trim(),
                        'profile_image': ''
                      }).then((value) async {
                        setState(() {
                          isLoading = false;
                        });
                        Get.snackbar("Success", 'SignUp successfully',
                            snackPosition: SnackPosition.BOTTOM);
                        print("${value.user}");
                        print("Successfully enter.");
                        storeUserData(value, true);

                        Get.offAllNamed(RoutesClass.getMainScreenRoute());
                      }).catchError((error) {
                        Get.snackbar("$error", '$error',
                            snackPosition: SnackPosition.BOTTOM);
                        setState(() {
                          isLoading = false;
                        });
                      });
                    } catch (e) {
                      Get.snackbar("Error", '$e',
                          snackPosition: SnackPosition.BOTTOM);
                      setState(() {
                        isLoading = false;
                      });
                    }
                  }
                }),
                normalColor: ColorPalette.appColor,
              ),
              spacerV50,
            ],
          ),
        ),
      ),
    );
  }

  var apiService = ApiService();

  void uploadImages() async {
    try {
      final pickedFile =
          await ImagePicker().pickImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        print("Image path :: ${pickedFile.path}");
        var response = await apiService.uploadFile(pickedFile, {
          'first_name': _userName.text.trim(),
          'email': _emailController.text.trim(),
          'id': data.id
        });

        //   if (response.statusCode == 200) {
        //     //get image url from api response
        //     // imageURL = response.data['user']['image'];
        //     print('Dqata:::${response.body}');
        //     Get.snackbar('Success', 'Image uploaded successfully',
        //         margin: EdgeInsets.only(top: 5, left: 10, right: 10));
        //   } else if (response.statusCode == 401) {
        //     Get.offAllNamed('/sign_up');
        //   } else {
        //     Get.snackbar('Failed', 'Error Code: ${response.statusCode}',
        //         margin: EdgeInsets.only(top: 5, left: 10, right: 10));
        //   }
        // } else {
        //   Get.snackbar('Failed', 'Image not selected',
        //       margin: EdgeInsets.only(top: 5, left: 10, right: 10));
      }
    } finally {
      // isLoading(false);
    }
  }

  late File selectedImage;

  Future getImages() async {
    var image = await ImagePicker().getImage(source: ImageSource.gallery);

    setState(() {
      selectedImage = File(image!.path);
    });
  }

  onUploadImage() async {
    var request = http.MultipartRequest(
      'POST',
      Uri.parse("http://mrmodh11.pythonanywhere.com/userProfileUpdate"),
    );
    Map<String, String> headers = {"Content-type": "multipart/form-data"};
    request.files.add(
      http.MultipartFile(
        'image',
        selectedImage.readAsBytes().asStream(),
        selectedImage.lengthSync(),
        filename: selectedImage.path.split('/').last,
      ),
    );
    request.headers.addAll(headers);
    print("request: " + request.toString());
    var res = await request.send();
    http.Response response = await http.Response.fromStream(res);
    final resa = convert.jsonDecode(response.body);
    print("data:: ${resa}");
  }
}
