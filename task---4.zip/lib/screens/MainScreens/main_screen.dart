import 'package:animations/animations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import '../../utils/utils.dart';
import '../account_screen/account_screen.dart';
import '../cart_screen/cart_screen.dart';
import '../explore_screen/explore_screen.dart';
import '../favourite_screen/favourite_screen.dart';
import '../shop_screen/shop_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  //Bottom NavBar Index And there Contant
  int page = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    ShopScreen(),
    ExploreScreen(),
    CartScreen(),
    FavouriteScreen(),
    AccountScreen()
  ];

  void _onItemTapped(int index) {
    setState(() {
      page = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        //Body
       
        body: PageTransitionSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (child, primaryAnimation, secondaryAnimation) =>
          FadeThroughTransition(
        animation: primaryAnimation,
        secondaryAnimation: secondaryAnimation,
        child: child,
      ),
      child: _widgetOptions.elementAt(page),
        ),
    
        //Bottom bar
        bottomNavigationBar: Padding(
      padding: EdgeInsets.symmetric(vertical: 5.h),
      child: BottomNavigationBar(
        elevation: 0,
        currentIndex: page,
        selectedLabelStyle: heading4_b,
        selectedItemColor: ColorPalette.appColor,
        selectedFontSize: 16,
        unselectedFontSize: 16,
        unselectedItemColor: ColorPalette.black,
        unselectedLabelStyle: heading4_b,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        iconSize: 40,
        items: [
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: SvgPicture.asset(
                ImageStorage.icons.homeIcon,
                color: page == 0 ? ColorPalette.appColor : ColorPalette.black,
                width: 28.w,
                height: 28.w,
              ),
            ),
            label: 'Shop',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: SvgPicture.asset(
                ImageStorage.icons.searchIcon,
                color: page == 1 ? ColorPalette.appColor : ColorPalette.black,
                width: 23.w,
                height: 23.w,
              ),
            ),
            label: 'Explore',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: SvgPicture.asset(
                ImageStorage.icons.cartIcon,
                color: page == 2 ? ColorPalette.appColor : ColorPalette.black,
                width: 26.w,
                height: 26.w,
              ),
            ),
            label: 'Cart',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: SvgPicture.asset(
                ImageStorage.icons.favIcon,
                color: page == 3 ? ColorPalette.appColor : ColorPalette.black,
                width: 27.w,
                height: 27.w,
              ),
            ),
            label: 'Favourite',
          ),
          BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.symmetric(vertical: 1.5),
              child: SvgPicture.asset(
                ImageStorage.icons.personIcon,
                color: page == 4 ? ColorPalette.appColor : ColorPalette.black,
                width: 28.w,
                height: 28.w,
              ),
            ),
            label: 'Account',
          ),
        ],
        onTap: (index) {
          _onItemTapped(index);
        },
      ),
        ),
      ),
    );
  }
}
