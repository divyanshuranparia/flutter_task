import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../utils/utils.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool? isLog;
  @override
  void initState() {
    getLogIn();
    super.initState();

    Timer(
            const Duration(seconds: 2),
            () => isLog == true
                ? Get.offAllNamed(RoutesClass.getMainScreenRoute())
                : Get.offAllNamed(RoutesClass.getWelcomeScreenRoute(),
                    arguments: ''));
  }

  getLogIn() async {
    SharedPreferences sharedPreferences1 =
        await SharedPreferences.getInstance();
    isLog = sharedPreferences1.getBool('isLogin');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorPalette.appColor,
      body: Center(
        child: Image.asset(
          ImageStorage.images.logo,
          height: 200.w,
        ),
      ),
    );
  }
}
