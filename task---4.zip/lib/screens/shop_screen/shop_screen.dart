import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:four_d_app/custom_widgets/grid_products.dart';
import 'package:four_d_app/custom_widgets/groceries_grid.dart';
import 'package:four_d_app/models/product_model/product_model.dart';
import 'package:get/get.dart';

import '../../models/getResponse.dart';
import '../../services/api_service.dart';
import '../../utils/app_textfiled.dart';
import '../../utils/utils.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({Key? key}) : super(key: key);

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  TextEditingController _search = TextEditingController();
  int _index = 0;
  bool isLoading = true;
  List<Product> products = [];
  List<Product> bestSellings = [];
  List<Product> exclusiveOffers = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() {
    var apiService = ApiService();
    try {
      print("API calll..");
      products = [];
      bestSellings = [];
      exclusiveOffers = [];
      apiService.fetchData().then((DashBoardModal value) async {
        print('Data of products : ${value.data}');
        products = value.data;
        bestSellings = products
            .where((element) => element.product_type == 'best_seller')
            .toList();
        exclusiveOffers = products
            .where((element) => element.product_type == 'exclusive_offer')
            .toList();
        print('Best : $bestSellings');
        print('exclusive : $exclusiveOffers');
        print("Produtcs :: ${products[0].product_images![1].image}");
        setState(() {
          isLoading = false;
        });
        // Get.snackbar("Success", 'Login successfully',
        //     snackPosition: SnackPosition.BOTTOM);
        // print("${value.user}");
        print("Successfully enter.");
        // storeUserData(value, true);

        // Get.offAllNamed(RoutesClass.getMainScreenRoute());
      }).catchError((error) {
        print("Error:: $error");
        Get.snackbar("$error", '$error', snackPosition: SnackPosition.BOTTOM);
        setState(() {
          isLoading = false;
        });
      });
    } catch (e) {
      print("Error:: $e");
      Get.snackbar("Error", '$e', snackPosition: SnackPosition.BOTTOM);
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(
              child: Loader(),
            )
          : SizedBox(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    spacerV50,
                    spacer30,
                    Image.asset(
                      ImageStorage.images.carrotColor,
                      height: 40.w,
                      width: 40.w,
                    ),
                    spacerV10,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.location_on_sharp,
                          color: ColorPalette.blueGrey,
                          size: 26.sp,
                        ),
                        Text(
                          ' $dhakaBanassre',
                          style: heading2_18_w.copyWith(
                              color: ColorPalette.blueGrey,
                              fontWeight: FontWeight.w500),
                        )
                      ],
                    ),
                    Container(
                        // alignment: Alignment.centerLeft,
                        margin: EdgeInsets.all(15),
                        height: 60.h,
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: ColorPalette.dartWhite,
                            borderRadius: BorderRadius.circular(20.r)),
                        child: Center(
                          child: AppTextField(
                            textEditingController: _search,
                            prifex: true,
                            counterText: true,
                            isBorder: true,
                            onChanged: (e) async {},
                            hintText: searchStore,
                            maxLines: 1,
                            keyboardType: TextInputType.name,
                            onFieldSubmitted: (val) {},
                          ),
                        )),
                    spacerV10,
                    SizedBox(
                      height: 130.h,
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          PageView.builder(
                            itemCount: 5,
                            controller: PageController(viewportFraction: 0.90),
                            onPageChanged: (int index) =>
                                setState(() => _index = index),
                            itemBuilder: (_, i) {
                              return Transform.scale(
                                scale: i == _index ? 1 : 0.9,
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: Image.asset(
                                      ImageStorage.images.ads,
                                      fit: BoxFit.cover,
                                    )),
                              );
                            },
                          ),
                          Positioned(
                            bottom: 15,
                            child: SizedBox(
                              height: 9.w,
                              child: ListView.builder(
                                shrinkWrap: true,
                                scrollDirection: Axis.horizontal,
                                itemCount: 5,
                                itemBuilder: (context, index) =>
                                    AnimatedContainer(
                                  height: 2.w,
                                  width: _index == index ? 25.w : 8.w,
                                  margin: EdgeInsets.symmetric(horizontal: 2.w),
                                  decoration: BoxDecoration(
                                      color: _index == index
                                          ? ColorPalette.appColor
                                          : ColorPalette.lightGrey,
                                      borderRadius: BorderRadius.circular(30)),
                                  duration: Duration(milliseconds: 200),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    exclusiveOffers == []
                        ? SizedBox()
                        : Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 20.h, horizontal: 20.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(exclusiveOffer,
                                    style: heading1.copyWith(
                                        color: ColorPalette.black,
                                        letterSpacing: 1.2)),
                                Text(seeAll,
                                    style: heading1.copyWith(
                                        fontSize: 16, letterSpacing: 1.2))
                              ],
                            ),
                          ),
                    exclusiveOffers == []
                        ? SizedBox()
                        : SizedBox(
                            height: 240,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (ctx, index) {
                                return GridProducts(exclusiveOffers[index]);
                              },
                              itemCount: exclusiveOffers.length,
                            ),
                          ),
                    bestSellings == []
                        ? SizedBox()
                        : Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 20.h, horizontal: 20.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(bestSelling,
                                    style: heading1.copyWith(
                                        color: ColorPalette.black,
                                        letterSpacing: 1.2)),
                                Text(seeAll,
                                    style: heading1.copyWith(
                                        fontSize: 16, letterSpacing: 1.2))
                              ],
                            ),
                          ),
                    bestSellings == []
                        ? SizedBox()
                        : SizedBox(
                            height: 240,
                            child: ListView.builder(
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (ctx, index) {
                                return GridProducts(bestSellings[index]);
                              },
                              itemCount: bestSellings.length,
                            ),
                          ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 20.h, horizontal: 20.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(groceries,
                              style: heading1.copyWith(
                                  color: ColorPalette.black,
                                  letterSpacing: 1.2)),
                          Text(seeAll,
                              style: heading1.copyWith(
                                  fontSize: 16, letterSpacing: 1.2))
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 90,
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (ctx, index) {
                          return GroceriesGrid(groceriesList[index]);
                        },
                        itemCount: groceriesList.length,
                      ),
                    ),
                    spacerV20,
                    SizedBox(
                      height: 240,
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (ctx, index) {
                          return GridProducts(exclusiveOffers[index]);
                        },
                        itemCount: exclusiveOffers.length,
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
