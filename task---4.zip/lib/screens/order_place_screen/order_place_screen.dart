import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:get/get.dart';

import '../../utils/utils.dart';

class OrderPlaceScreen extends StatefulWidget {
  const OrderPlaceScreen({Key? key}) : super(key: key);

  @override
  State<OrderPlaceScreen> createState() => _OrderPlaceScreenState();
}

class _OrderPlaceScreenState extends State<OrderPlaceScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height - 40,
          margin: EdgeInsets.only(top: 40.h),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(ImageStorage.images.loginSignupB),
              fit: BoxFit.fill,
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.all(20),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              spacerV50,
              spacerV50,
              spacerV20,
              Center(
                  child: Padding(
                padding: EdgeInsets.only(right: 25.w),
                child: Image.asset(
                  ImageStorage.images.orderCom,
                  height: 250.h,
                  width: 250.h,
                ),
              )),
              spacerV40,
              const Text(
                yourOrderHasBeen,
                style: heading2_20_b,
              ),
              spacerV5,
              const Text(
                accepted,
                style: heading2_20_b,
              ),
              spacerV20,
              Text(
                disOfOrder,
                style: heading4.copyWith(
                    fontSize: 16, fontWeight: FontWeight.w600),
              ),
              spacerV5,
              Text(
                disOfOrder_,
                style: heading4.copyWith(
                    fontSize: 16, fontWeight: FontWeight.w600),
              ),
              const Spacer(),
              AppButton(
                text: trackOrder,
                onPressed: () {
                  Get.back();
                  Get.back();
                },
                normalColor: ColorPalette.appColor,
              ),
              spacerV10,spacerV5,
              AppButton(
                text: backToHome,
                textColor: ColorPalette.black,
                onPressed: () {
                  Get.offAllNamed(RoutesClass.getMainScreenRoute());
                },
                normalColor: Colors.transparent,
              ),  spacerV20
            ],
          ),
        )
      ]),
    );
  }
}
