
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:four_d_app/utils/utils.dart';
import 'package:get/get.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';



void main() async {
    
    WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with AppThemeMixin {
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(450, 890),
      minTextAdapt: true,
      
      splitScreenMode: true,
      builder: (BuildContext context, Widget? child) {
        return GetMaterialApp(
          
          title: 'nectar',
          debugShowCheckedModeBanner: false,
          theme: appTheme(context),
          scrollBehavior: const ScrollBehaviorModified(),
          initialRoute: RoutesClass.getSplashRoute(),
          getPages: RoutesClass.routes,
        );
      },
    );
  }
}

class ScrollBehaviorModified extends ScrollBehavior {
  const ScrollBehaviorModified();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const BouncingScrollPhysics();
  }
}
