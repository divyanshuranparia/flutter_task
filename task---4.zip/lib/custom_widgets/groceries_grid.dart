import 'package:flutter/material.dart';
import 'package:four_d_app/models/product_model/product_model.dart';

import '../utils/utils.dart';

class GroceriesGrid extends StatelessWidget {
  GroceriesModel product;
   GroceriesGrid(this.product,{Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      margin: EdgeInsets.only(left: 20.w),
                      width: MediaQuery.of(context).size.width / 2,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20.r),
                          color: product.color),
                      child: Row(
                        children: [
                          spacerH10,
                          SizedBox(
                              height: 85,
                              width: 85,
                              child: Image.asset(product.img)),
                          spacerH20,
                          Text(product.name,
                              style: heading2.copyWith(
                                  color: Color(0xff3E423F),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800))
                        ],
                      ),
                    );
  }
}