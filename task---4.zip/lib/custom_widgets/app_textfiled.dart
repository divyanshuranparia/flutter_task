import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/utils.dart';

class AppTextField extends StatelessWidget {
  final String? title;
  final String? hintText;
  final TextEditingController? textEditingController;
  final bool? obscureText;
  final IconData? prefix;
  final TextInputType? keyboardType;
  final GestureTapCallback? onPressed;
  final ValueChanged<String?> onChanged;
  final FormFieldValidator<String>? validator;
  final TextCapitalization? textCapitalization;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onFieldSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final GestureTapCallback? onTap;
  final Widget? suffixIcon;
  final bool? readOnly;
  final String? errorText;
  final int? maxLines;
  final int? maxLength;
  final bool? counterText;
  final bool? prifex;
  final bool? autoFocus;
  const AppTextField(
      {Key? key,
      this.title,
      this.prifex,
      this.autoFocus,
      this.inputFormatters,
      required this.onChanged,
      this.counterText,
      this.errorText,
      this.readOnly,
      this.suffixIcon,
      this.prefix,
      this.hintText,
      this.focusNode,
      this.onPressed,
      this.textEditingController,
      this.obscureText = false,
      this.keyboardType,
      this.validator,
      this.textCapitalization,
      this.textInputAction,
      this.maxLines = 1,
      this.onFieldSubmitted,
      this.maxLength,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
            alignment: Alignment.centerLeft,
            child: Text(
              title ?? "",
              style: textStyle16.copyWith(color: ColorPalette.lightGrey),
            )),
        SizedBox(
          child: TextFormField(
            autovalidateMode: AutovalidateMode.onUserInteraction,
            obscureText: obscureText!,
            readOnly: readOnly ?? false,
            onTap: onTap,
            onChanged: onChanged,
            autofocus: autoFocus == true ? true : false,
            controller: textEditingController,
            validator: validator,
            style: heading2,
            cursorColor: ColorPalette.appColor,
            maxLines: maxLines,
            maxLength: maxLength,
            focusNode: focusNode,
            textInputAction: textInputAction,
            onFieldSubmitted: onFieldSubmitted,
            decoration: InputDecoration(
              errorText: errorText,
              counterText: counterText == true ? '' : null,
              border: inputBorder,
              focusedBorder: inputBorder,
              enabledBorder: inputBorder,
              errorBorder: inputBorder,
              disabledBorder: inputBorder,
              focusedErrorBorder: inputBorder.copyWith(
                  borderSide: BorderSide(color: Colors.orange)),
              hintText: hintText ?? 'Enter Details',
              errorStyle: TextStyle(color: Colors.orange, fontSize: 14.sp),
              prefix: prifex == true
                  ? Padding(
                      padding: const EdgeInsets.all(4),
                      child: Text(
                        '+91',
                        style: heading2,
                      ),
                    )
                  : null,
              suffixIcon: suffixIcon != null
                  ? InkWell(onTap: onPressed, child: suffixIcon)
                  : onPressed != null
                      ? InkWell(
                          onTap: () {
                            // textEditingController?.clear();
                          },
                          child: Icon(
                            obscureText!
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: Colors.black,
                          ),
                        )
                      : null,
              suffixIconColor: ColorPalette.appColor,
              suffixStyle: TextStyle(color: ColorPalette.appColor),
              //  labelText: title,
              floatingLabelBehavior: FloatingLabelBehavior.auto,
              hintStyle:
                  textStyle16.copyWith(color: ColorPalette.semiLightGrey),
              //    fillColor: Colors.white
            ),
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            //cursorColor: Colors.white,
          ),
        ),
        SizedBox(
          height: 5,
        ),
        // Padding(
        //   padding: const EdgeInsets.only(left: 5.0),
        //   child: getValidationStatus(),
        // ),
      ],
    );
  }

  InputBorder get inputBorder => UnderlineInputBorder(
      borderSide: BorderSide(color: Colors.black, width: 1));
}
