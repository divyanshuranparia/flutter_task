import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/utils.dart';

class AppTextField extends StatelessWidget {
  final String? title;
  final String? hintText;
  final TextEditingController? textEditingController;
  final bool? obscureText;
  final IconData? prefix;
  final TextInputType? keyboardType;
  final GestureTapCallback? onPressed;
  final ValueChanged<String?> onChanged;
  final FormFieldValidator<String>? validator;
  final TextCapitalization? textCapitalization;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onFieldSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final GestureTapCallback? onTap;
  final Widget? suffixIcon;
  final bool? readOnly;
  final String? errorText;
  final int? maxLines;
  final int? maxLength;
  final bool? counterText;
  final bool? prifex;
  final bool? autoFocus;
  const AppTextField(
      {Key? key,
      this.title,
      this.prifex,
      this.autoFocus,
      this.inputFormatters,
      required this.onChanged,
      this.counterText,
      this.errorText,
      this.readOnly,
      this.suffixIcon,
      this.prefix,
      this.hintText,
      this.focusNode,
      this.onPressed,
      this.textEditingController,
      this.obscureText = false,
      this.keyboardType,
      this.validator,
      this.textCapitalization,
      this.textInputAction,
      this.maxLines = 1,
      this.onFieldSubmitted,
      this.maxLength,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration:  BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.all(Radius.circular(12)),
          boxShadow: [
           BoxShadow(
                    offset: Offset(0,1),
                    blurRadius: 5,
                    color: Colors.black.withOpacity(0.3),
                  ),
          ]
          ),
          child: Center(
            child: TextFormField(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              obscureText: obscureText!,
              readOnly: readOnly ?? false,
              onTap: onTap,
              onChanged: onChanged,
              // autofocus: autoFocus == true ? true : false,
              controller: textEditingController,
              validator: validator,
              style: heading2,
              cursorColor: ColorPalette.appColor,
              maxLines: maxLines,
              maxLength: maxLength,
              focusNode: focusNode,
              textInputAction: textInputAction,
              onFieldSubmitted: onFieldSubmitted,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.fromLTRB(16.w, 12.0.h, 16.0.w, 12.0.h),
                
                errorText: errorText,
                // counterText: counterText == true ? '' : null,
                border: InputBorder.none,
                hintText: hintText ?? 'Enter Details',
                
                errorStyle: TextStyle(color: Colors.orange, fontSize: 14.sp),
                prefixIcon: prifex == true
                    ?  Padding(
                        padding:  EdgeInsets.all(4),
                        child: Icon(CupertinoIcons.search,size: 28.h,color: Colors.black,)
                      )
                    : null,
                floatingLabelBehavior: FloatingLabelBehavior.auto,
                hintStyle:
                    heading3,
                //    fillColor: Colors.white
              ),
              keyboardType: keyboardType,
              inputFormatters: inputFormatters,
              //cursorColor: Colors.white,
            ),
          ),
        ),
        
      ],
    );
  }
}