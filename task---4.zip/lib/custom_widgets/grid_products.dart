// ignore_for_file: must_be_immutable
import 'package:flutter/material.dart';
import 'package:four_d_app/models/product_model/product_model.dart';
import 'package:get/get.dart';
import '../models/getResponse.dart';
import '../utils/utils.dart';
import 'button.dart';

class GridProducts extends StatelessWidget {
 Product products;

  GridProducts(this.products, {Key? key}) : super(key: key);
  String baseUrl = 'http://mrmodh11.pythonanywhere.com';

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Get.toNamed(RoutesClass.getProductDetailScreenRoute(),arguments: products);
      },
      child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                margin: EdgeInsets.only(left:20.w),
                width: 160,
            
                decoration: BoxDecoration(    color: Colors.grey[200],
                    border: Border.all(
                      color: ColorPalette.borderColor,
                      width: 2.5.w,
                    ),
                    borderRadius: BorderRadius.circular(20.r)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: SizedBox(
                        height: 85,
                        width: 85,
                        child: Image.network(baseUrl+products.product_images![0].image.toString())),
                    ),
                      // ImageStorage.images.apple)),
                    spacerV20,
                    Text(products.product_name.toString(),
                        style: heading2.copyWith(
                            color: ColorPalette.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                            spacerV5,
                    Text(products.product_dic.toString(),
                        style: heading2.copyWith(
                            color: ColorPalette.textgrey,
                            fontSize: 15,
                            fontWeight: FontWeight.bold)),
                    spacerV20,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(products.product_discount_price.toString(),
                            style: heading2.copyWith(
                                color: ColorPalette.black,
                                fontSize: 16,letterSpacing: 1.1,
                                fontWeight: FontWeight.w800)),
                        AppButton(
                          icon: Icons.add,
                          normalColor: ColorPalette.appColor,
                          text: '',
                          onPressed: () {},
                          width: 45.w,
                          height: 45.w,
                          isRadius10: true,
                          iconColor: ColorPalette.white,
                        )
                      ],
                    )
                  ],
                ),
              ),
    );
  }
}
