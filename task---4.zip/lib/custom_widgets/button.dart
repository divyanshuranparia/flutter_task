// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:four_d_app/utils/theme/color_palette.dart';

// class MainButton extends StatelessWidget {
//   final String text;
//   final GestureTapCallback onTap;
//   final double height;
//   final double? width;
//   MainButton(
//       {Key? key,
//       required this.text,
//       required this.onTap,
//       required this.height,
//       this.width})
//       : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       height: height.h,
//       width: width,
//       decoration: BoxDecoration(
//           gradient: LinearGradient(
//         begin: Alignment.topLeft,
//         end: Alignment.bottomRight,
//         stops: [0.01, 0.09, 0.7],
//         colors: [
//           ColorPalette.lightblack,
//           Color(0xff2A2A2A),
//           ColorPalette.black,
//         ],
//       )),
//     );
//   }
// }

import 'package:flutter/material.dart';
import '../../utils/utils.dart';

class AppButton extends StatelessWidget {
  final String text;
  final Function() onPressed;
  final Color? textColor;
  final Gradient? btnColor;
  final double? width;
  final IconData? icon;
  final Color? iconColor;
  final bool? isRotate;
  final bool? isRadius100;
  final Color? normalColor;
  final String? image;
  final bool? isRadius10;
  final bool? isPrice;
  final bool? iconSize;

  final double? height;
  const AppButton({
    Key? key,
    required this.text,
    required this.onPressed,
    this.textColor,
    this.isPrice,
    this.iconSize,
    this.normalColor,
    this.isRadius100,
    this.btnColor,
    this.height,
    this.iconColor,
    this.icon,
    this.isRadius10,
    this.isRotate,
    this.image,
    this.width,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: ColorPalette.semiLightGrey,
      overlayColor: MaterialStateProperty.resolveWith(
        (states) {
          return states.contains(MaterialState.pressed)
              ? ColorPalette.lightGrey
              : null;
        },
      ),
      onTap: onPressed,
      child: Container(
        width: width ?? MediaQuery.of(context).size.width,
        height: height ?? 70.h,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            boxShadow: const [
              BoxShadow(
                color: Color.fromRGBO(100, 100, 111, 0.2),
                offset: Offset(0, 7),
                blurRadius: 29,
                spreadRadius: 0,
              ),
            ],
            color: normalColor ?? ColorPalette.appColor,
            borderRadius: isRadius100 == true ? radius100 :isRadius10 == true?radius10+radius5: radius20,
            gradient: normalColor != null
                ? null
                : btnColor ?? ColorPalette.buttonGradient),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon == null
                ? const SizedBox()
                : isRotate == true
                    ? Transform.rotate(
                        angle: 360 / 65,
                        child: Icon(
                          icon,
                          color: iconColor,
                          size: 30,
                        ),
                      )
                    : Icon(
                        icon,
                        color: iconColor,
                        size:iconSize==true?25: 30,
                      ),
            image == null ? const SizedBox() : SizedBox(
              height: 25.w,
              width: 25.w,
              child: Image.asset(image.toString(),fit: BoxFit.contain,)),
            icon == null ? const SizedBox() :text==''?const SizedBox(): spacerH10,
            image == null?const SizedBox():spacerH40,
            Center(
              child: Text(
                text,
                style: textStyle20.copyWith(color: textColor ?? Colors.white,fontWeight: FontWeight.w700,letterSpacing: 1.3),
              ),
            ),
            isPrice!=true?SizedBox():  Container(
                      padding: EdgeInsets.all(5),
                      margin: EdgeInsets.only(left: 10),
                      decoration: BoxDecoration(
                          color:Color(0xff489E67),
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        "\$12.96",
                        style: heading4.copyWith(color: Colors.white),
                      ),
                    ),
          ],
        ),
      ),
    );
  }
}
