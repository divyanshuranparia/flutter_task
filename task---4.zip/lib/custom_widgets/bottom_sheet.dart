import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:four_d_app/custom_widgets/button.dart';
import 'package:get/get.dart';
import '../utils/utils.dart';

class BottomSheetHotel {
  static Future bottomSheetHotel(BuildContext context) {
    return showModalBottomSheet<void>(
      elevation: 0,
      context: context,
      backgroundColor: Colors.transparent,
      clipBehavior: Clip.hardEdge,
      builder: (BuildContext context) {
        bool isLoad = false;
        return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Container(
              height: 600,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30.r),
                      topRight: Radius.circular(30.r))),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const [
                          Text(checkout, style: heading2_20_b),
                          Icon(Icons.close)
                        ],
                      ),
                    ),
                    spacerV10,
                    spacerV5,
                    const Divider(
                      thickness: 1.3,
                    ),
                    spacerV10,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(delivery,
                              style: heading4.copyWith(
                                  fontSize: 17, fontWeight: FontWeight.w600)),
                          Row(
                            children: [
                              Text(selectMethod,
                                  style: heading4_b.copyWith(
                                      fontSize: 15, fontWeight: FontWeight.w600)),
                              Icon(
                                Icons.keyboard_arrow_right_rounded,
                                size: 25,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    spacerV10,
                    const Divider(
                      thickness: 1.3,
                    ),
                    spacerV10,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(pament,
                              style: heading4.copyWith(
                                  fontSize: 17, fontWeight: FontWeight.w600)),
                          Row(
                            children: [
                              Image.asset(ImageStorage.images.card),
                              Icon(
                                Icons.keyboard_arrow_right_rounded,
                                size: 25,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    spacerV10,
                    const Divider(
                      thickness: 1.3,
                    ),
                    spacerV10,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(promoCode,
                              style: heading4.copyWith(
                                  fontSize: 17, fontWeight: FontWeight.w600)),
                          Row(
                            children: [
                              Text(pickDiscount,
                                  style: heading4_b.copyWith(
                                      fontSize: 15, fontWeight: FontWeight.w600)),
                              Icon(
                                Icons.keyboard_arrow_right_rounded,
                                size: 25,
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    spacerV10,
                    const Divider(
                      thickness: 1.3,
                    ),
                    spacerV10,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(totalCost,
                              style: heading4.copyWith(
                                  fontSize: 17, fontWeight: FontWeight.w600)),
                          Row(
                            children: [
                              Text('\$13.97',
                                  style: heading4_b.copyWith(
                                      fontSize: 15, fontWeight: FontWeight.w600)),
                              Icon(
                                Icons.keyboard_arrow_right_rounded,
                                size: 25,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    spacerV10,
                    const Divider(
                      thickness: 1.3,
                    ),
                    spacerV5,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Text(policy,
                          style: heading4.copyWith(
                              fontSize: 15, fontWeight: FontWeight.w600)),
                    ),
                    spacerV5,
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Row(
                        children: [
                          Text(terms,
                              style: heading4.copyWith(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: ColorPalette.black)),
                          Text(" $and ",
                              style: heading4.copyWith(
                                  fontSize: 15, fontWeight: FontWeight.w600)),
                          Text(conditions,
                              style: heading4.copyWith(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: ColorPalette.black)),
                        ],
                      ),
                    ),
                    spacerV20,
                    AppButton(
                      text: placeOrder,
                      onPressed: () {
                        Get.toNamed(RoutesClass.getOrderPlaceScreenRoute());
                      },
                      normalColor: ColorPalette.appColor,
                    )
                  ],
                ),
              ));
        });
      },
    );
  }
}
