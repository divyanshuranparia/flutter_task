import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../utils/utils.dart';

class ProductDetailImage extends StatelessWidget {
  const ProductDetailImage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return    Container(
                // height: 250.h,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: ColorPalette.dartWhite,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(30.r),
                        bottomRight: Radius.circular(30.r))),
                child: Column(
                  children: [
                    spacerV50,
                    spacer20,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                            onPressed: () {
                              Get.back();
                            },
                            icon: Icon(Icons.arrow_back)),
                        IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.ios_share_outlined)),
                      ],
                    ), spacer20,
                    SizedBox(
                      height: 200.h,
                      child: Image.asset(
                                       ImageStorage.images.appleDis,
                        fit: BoxFit.contain,
                      ),
                    ),
                    spacerV30,
                    SizedBox(
                      height: 7.w,
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemCount: 4,
                        itemBuilder: (context, index) => AnimatedContainer(
                          height: 2.w,
                          width: 1 == index ? 20.w : 8.w,
                          margin: EdgeInsets.symmetric(horizontal: 2.w),
                          decoration: BoxDecoration(
                              color: 1 == index
                                  ? ColorPalette.appColor
                                  : ColorPalette.lightGrey,
                              borderRadius: BorderRadius.circular(30)),
                          duration: Duration(milliseconds: 200),
                        ),
                      ),
                    ),
                    spacerV30
                  ],
                ));
  }
}