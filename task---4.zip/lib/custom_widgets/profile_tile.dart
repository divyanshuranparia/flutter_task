import 'package:flutter/material.dart';
import 'package:four_d_app/utils/utils.dart';

class ProfileTile extends StatelessWidget {
  final String title;
  final Widget icon;
  final VoidCallback? onTap;
  final Color? color;
  final bool? betch;

  const ProfileTile(
      {Key? key,
      required this.title,
      required this.icon,
      this.onTap,
      this.betch,
      this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap ?? () {},
      child: Container(
        margin: paddingV4,
        padding: EdgeInsets.symmetric(horizontal: 22.w, vertical: 10.h),
        width: MediaQuery.of(context).size.width,
        child: Row(
          children: [
            Container(child: icon),
            spacerH10,
            spacerH5,
            Text(title, style: textStyle16Bold.copyWith(letterSpacing: 1.0)),
            betch == null ? const SizedBox() : const Spacer(),
            betch == null
                ? const SizedBox()
                : const Icon(
                    Icons.keyboard_arrow_right_rounded,
                    size: 25,
                  ),
          ],
        ),
      ),
    );
  }
}
