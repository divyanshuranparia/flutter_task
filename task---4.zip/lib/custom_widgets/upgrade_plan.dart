import 'package:flutter/material.dart';
import 'package:four_d_app/utils/utils.dart';
import 'package:get/get.dart';

showUpgradePlanDialog({GestureTapCallback? onTap}) {
  showDialog(
      context: Get.context!,
      builder: (context) {
        return SimpleDialog(
          insetPadding: EdgeInsets.symmetric(horizontal: 80.w),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          children: [
            const SizedBox(
              height: 20,
            ),
            Image.asset(
              ImageStorage.images.alertTriangle,
              width: 50.w,
              height: 50.w,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.h),
              child: Center(
                  child: Text(
                "Upgrade your plan ",
                textAlign: TextAlign.center,
                style: heading2,
                // const TextStyle(fontWeight: FontWeight.w500),
              )),
            ),
            const SizedBox(
              height: 5,
            ),
            Center(
                child: Text("Your plan is finish so upgrade your plan.",
                    textAlign: TextAlign.center, style: heading3)),
            const SizedBox(
              height: 20,
            ),
          ],
        );
      });
}
