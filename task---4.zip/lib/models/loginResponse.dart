class LoginResponse {
  User? user;
  String? token;
  String? status;
  String? message;

  LoginResponse({this.user, this.token, this.status, this.message});

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
      user: User.fromJson(json['data']),
      token: json['token'],
      status: json['status'].toString(),
      message: json['message']);

  Map toJson() => {'user': user?.toJson(), 'token': token, 'status': status};
}

class User {
  String? id;
  bool? isActive = false;
  String? dateJoined;
  String? name;
  String? lastName;
  String? email;
  String? profileImage;

  User(
      {this.email,
      this.name,
      this.id,
      this.dateJoined,
      this.isActive,
      this.lastName,
      this.profileImage});

  factory User.fromJson(Map<String, dynamic> json) => User(
      email: json['email'],
      name: json['first_name'],
      id: json['id'].toString(),
      isActive: json['is_active'],
      dateJoined: json['date_joined'],
      lastName: json['last_name'],
      profileImage: json['profile_image']);

  Map toJson() => {
        'name': name,
        'email': email,
        'id': id,
        'is_active': isActive,
        'date_joined': dateJoined,
        'last_name': lastName,
        'profile_image': profileImage,
      };
}
