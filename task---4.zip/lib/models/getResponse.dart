class DashBoardModal {
  String status;
  String message;
  List<Product> data;

  DashBoardModal({
    required this.message,
    required this.status,
    required this.data,
  });

  factory DashBoardModal.fromjson(Map<String, dynamic> json) => DashBoardModal(
      message: json['message'],
      status: json['status'].toString(),
      data: (json['data'] as List).map((e) => Product.fromJson(e)).toList());

  Map<String, dynamic> toJson() => {
        'message': message,
        'status': status,
        'data': data.map((e) => e.toJson()).toList(),
      };
}

class Product {
  String? id;
  String? product_name;
  String? product_dic;
  double? product_price;
  double? product_discount_price;
  String? product_type;
  List<Photo>? product_images;

  Product(
      {this.product_images,
      this.product_type,
      this.product_name,
      this.product_dic,
      this.product_price,
      this.product_discount_price,
      this.id});

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'].toString();
    product_images =
        (json['product_images'] as List).map((e) => Photo.fromJson(e)).toList();
    product_name = json['product_name'];
    product_dic = json['product_dic'];
    product_price = json['product_price'];
    product_discount_price = json['product_discount_price'];
    product_type = json['product_type'];
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'product_images': product_images?.map((e) => e.toJson()).toList(),
        'product_dic': product_dic,
        'product_price': product_price,
        'product_discount_price': product_discount_price,
        'product_type': product_type
      };
}

class Photo {
  String? image;

  Photo({this.image});

  Photo.fromJson(Map<String, dynamic> json) {
    image = json['product_image'];
  }

  Map<String, dynamic> toJson() => {
        'image': image,
      };
}
