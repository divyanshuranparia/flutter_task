import 'dart:ui';

import 'package:four_d_app/utils/utils.dart';

class ProductModel {
  String img;
  String name;
  String dis;
  String price;

  ProductModel(
      {required this.img,
      required this.name,
      required this.dis,
      required this.price});
}

List productList = [
  ProductModel(
      img: ImageStorage.images.apple,
      name: redApple,
      dis: kgPriceg,
      price: '\$4.99'),
  ProductModel(
      img: ImageStorage.images.banana,
      name: organicBananas,
      dis: pcsPriceg,
      price: '\$4.99'),
  ProductModel(
      img: ImageStorage.images.chili,
      name: bellPepperRed,
      dis: kgPriceg,
      price: '\$4.99'),
  ProductModel(
      img: ImageStorage.images.adarak,
      name: ginger,
      dis: gmPriceg,
      price: '\$4.99'),
  ProductModel(
      img: ImageStorage.images.chikan,
      name: broilerChicken,
      dis: kgPriceg,
      price: '\$4.99'),
  ProductModel(
      img: ImageStorage.images.meat,
      name: beefBone,
      dis: gmPriceg,
      price: '\$4.99'),
];

List groceriesList = [
  GroceriesModel(
      img: ImageStorage.images.spice,
      name: pulses,
      color: ColorPalette.lightOrange),
  GroceriesModel(
      img: ImageStorage.images.rice, name: rice, color: ColorPalette.lightGreen)
];

class GroceriesModel {
  String img;
  String name;
  Color color;

  GroceriesModel({required this.img, required this.name, required this.color});
}

List coldDrink=[
  ColdDrink(img: ImageStorage.images.coke, name: dietCoke, dis: mlPrice,price: '\$1.50'),
  ColdDrink(img: ImageStorage.images.sprite, name: spriteCan, dis: mlPrice,price: '\$1.99'),
  ColdDrink(img: ImageStorage.images.tometo, name: appleGrapeJuice, dis: lPrice,price: '\$15.50'),
  ColdDrink(img: ImageStorage.images.cola, name: cocaColaCan, dis: mlPrice,price: '\$4.99'),
  ColdDrink(img: ImageStorage.images.pepsi, name: pepsiCan, dis: mlPrice,price: '\$4.99'),
];

class ColdDrink {
  String img;
  String name;
  String dis;
  String price;

  ColdDrink({required this.img, required this.name, required this.dis,required this.price});
}