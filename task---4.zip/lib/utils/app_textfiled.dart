import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/utils.dart';

class AppTextField extends StatelessWidget {
  final String? title;
  final String? hintText;
  final bool? isBorder;
  final TextEditingController? textEditingController;
  final bool? obscureText;
  final IconData? prefix;
  final TextInputType? keyboardType;
  final GestureTapCallback? onPressed;
  final ValueChanged<String?> onChanged;
  final FormFieldValidator<String>? validator;
  final TextCapitalization? textCapitalization;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onFieldSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final GestureTapCallback? onTap;
  final Widget? suffixIcon;
  final bool? readOnly;
  final String? errorText;
  final int? maxLines;
  final int? maxLength;
  final bool? counterText;
  final bool? prifex;
  final bool? autoFocus;
  const AppTextField(
      {Key? key,
      this.title,
      this.isBorder,
      this.prifex,
      this.autoFocus,
      this.inputFormatters,
      required this.onChanged,
      this.counterText,
      this.errorText,
      this.readOnly,
      this.suffixIcon,
      this.prefix,
      this.hintText,
      this.focusNode,
      this.onPressed,
      this.textEditingController,
      this.obscureText = false,
      this.keyboardType,
      this.validator,
      this.textCapitalization,
      this.textInputAction,
      this.maxLines = 1,
      this.onFieldSubmitted,
      this.maxLength,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: TextFormField(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        obscureText: obscureText!,
        readOnly: readOnly ?? false,
        onTap: onTap,
        onChanged: onChanged,
        autofocus: autoFocus == true ? true : false,
        controller: textEditingController,
        validator: validator,
        style: heading2_18_b_s,
        cursorColor: ColorPalette.black,

        maxLines: maxLines,
        maxLength: maxLength,
        focusNode: focusNode,
        textInputAction: textInputAction,
        onFieldSubmitted: onFieldSubmitted,
        decoration: InputDecoration(
          contentPadding: isBorder==true?  EdgeInsets.only(bottom: 15,top: 12):null,
          
          errorText: errorText,
          counterText: counterText == true ? '' : null,
          border:isBorder==true? InputBorder.none:inputBorder,
          focusedBorder: isBorder==true? InputBorder.none:inputBorder,
          enabledBorder: isBorder==true? InputBorder.none:inputBorder,
          errorBorder: isBorder==true? InputBorder.none:inputBorder,
          disabledBorder: isBorder==true? InputBorder.none:inputBorder,
          focusedErrorBorder: isBorder==true? InputBorder.none:inputBorder.copyWith(
              borderSide: BorderSide(color: Colors.orange)),
          hintText: hintText ?? 'Enter Details',
          errorStyle: TextStyle(color: Colors.orange, fontSize: 14.sp),
          prefixIcon: prifex == true
                  ? Padding(
                      padding: const EdgeInsets.all(4),
                      child: Icon(CupertinoIcons.search,color: ColorPalette.textgrey,)
                    )
                  : null,
          suffixIcon: suffixIcon != null
              ? InkWell(onTap: onPressed, child: suffixIcon)
              : onPressed != null
                  ? InkWell(
                      onTap: () {
                        // textEditingController?.clear();
                      },
                      child: Icon(
                        obscureText!
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: Colors.black,
                      ),
                    )
                  : null,
          suffixIconColor: ColorPalette.black,
          suffixStyle: TextStyle(color: ColorPalette.black),
           labelText: title,
          floatingLabelBehavior: FloatingLabelBehavior.auto,
          hintStyle:
              textStyle16.copyWith(color: ColorPalette.semiLightGrey),
          //    fillColor: Colors.white
        ),
        keyboardType: keyboardType,
        inputFormatters: inputFormatters,
        //cursorColor: Colors.white,
      ),
    );
  }

  InputBorder get inputBorder => UnderlineInputBorder(
      borderSide: BorderSide(color:  ColorPalette.lightGrey, width: 1));
}
