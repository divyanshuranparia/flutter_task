import 'dart:convert';

import 'package:four_d_app/models/loginResponse.dart';
import 'package:shared_preferences/shared_preferences.dart';

//for checking user is here
isLogin(isLogin) async {
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  sharedPreferences.setBool("isLogin", isLogin);
}

removeLogin() async {
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  sharedPreferences.remove("isLogin");
}

storeUserData(LoginResponse value,bool isLogin) async {
  final prefs = await SharedPreferences.getInstance();
  prefs.setBool("isLogin", isLogin);
  prefs.setString('id', (value.user!.id).toString());
  prefs.setString("token", (value.token).toString());
  prefs.setString("first_name", (value.user!.name).toString());
  prefs.setString("email", (value.user!.email).toString());
  prefs.setString("dateJoined", (value.user!.dateJoined).toString());
  prefs.setString("profileImage", (value.user!.profileImage).toString());
}

Future<List<Shared>> fetchData() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String id = prefs.getString('id').toString();
  String token = prefs.getString('token').toString();
  String first_name = prefs.getString('first_name').toString();
  String email = prefs.getString('email').toString();
  String dateJoined = prefs.getString('dateJoined').toString();
  String profileImage = prefs.getString('profileImage').toString();
  List<Shared> shared = [
    Shared(
        id: id,
        dateJoined: dateJoined,
        email: email,
        first_name: first_name,
        profileImage: profileImage,
        token: token)
  ];

  return shared;
}

class Shared {
  String? id;
  String? token;
  String? first_name;
  String? email;
  String? dateJoined;
  String? profileImage;

  Shared(
      {this.id,
      this.token,
      this.dateJoined,
      this.email,
      this.first_name,
      this.profileImage});
}
