import 'package:flutter/material.dart';
import 'package:four_d_app/utils/theme/color_palette.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

class Loader extends StatelessWidget {
  const Loader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LoadingAnimationWidget.flickr(
      leftDotColor: ColorPalette.appColor,
      rightDotColor: ColorPalette.semiLightGrey,
      size: 40,
    );
  }
}
