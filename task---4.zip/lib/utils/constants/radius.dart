
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/src/size_extension.dart';


final radius2 = BorderRadius.circular(2.r);
final radius5 = BorderRadius.circular(5.r);
final radius8 = BorderRadius.circular(8.r);
final radius10 =  BorderRadius.circular(10.r);
final radius20 =  BorderRadius.circular(20.r);
final radius30 =  BorderRadius.circular(30.r);
final radius40 =  BorderRadius.circular(40.r);
final radius100 =  BorderRadius.circular(100.r);
