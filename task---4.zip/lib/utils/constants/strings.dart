
//welcome screen
const String welcom = 'Welcome';
const String toOurStore = 'to our store';
const String gerYourGroceriesInAsFastAsOneHour = 'Ger your groceries in as fast as one hour';
const String welcomeButton = 'Get Started';

//signIn Screen
const String getYourgroceries = "Get your groceries";
const String withNectar = "with nectar";
const String orConnectWithSocialMedia = "Or connect with social media";
const String continueWithGoogle = "Continue with Google";
const String continuewithFacebook ="Continue with Facebook";

//Login Screen
const String loging ="Log in";
const String enterYourEmailsAndPassword = "Enter your emails and password"; 
const String email = "Email";
const String password = "Password";
const String forgotPassword = "Forgot Password?";
const String logIn = "Log In";
const String dontHaveAnAccount = "Dont't have an account?";
const String singUp = "Sing Up";

//SignUp Screen
const String enterYourCredentialsToContinue = "Enter your credentials to continue";
const String userName = "Username";
const String byContinuingYouAgreeToOur = "By continuing you agree to our";
const String termsOfService ="Terms of Service";
const String and = "and";
const String privacyPolicy = "Privacy Policy."; 
const String alreadyHaveAnAccount = "Already have an account?";

//shop screen
const String dhakaBanassre = "Dhaka, Banassre";
const String searchStore ="Search Store";
const String exclusiveOffer="Exclusive Offer";
const String seeAll ="See all";
const String organicBananas ="Organic Bananas";
const String pcsPriceg = "7pcs, Priceg";
const String redApple ="Red Apple";
const String kgPriceg ="1kg, Priceg";
const String bestSelling ="Best Selling";
const String bellPepperRed ="Bell Pepper Red";
const String ginger ="Ginger";
const String gmPriceg ="250gm, Priceg";
const String pulses ="Pulses";
const String rice ="Rice";
const String beefBone ="Beef Bone";
const String broilerChicken ="Broiler Chicken";    
const String groceries ="Groceries";  
const String naturelRedApple ="Naturel Red Apple";
const String longDis = "Apples are nutritious. Apples may be good for weight loss. apples may be good for your heart. As part of a healtful and varied diet.";
const String productDetail = "Product Detail";
const String nutritions ="Nutritions";
const String review = "Review";
const String addToBasket ="Add To Basket";

const String goToCheckout ="Go to Checkout";

const String addAllToCart = "Add All To Cart";
const String spriteCan = "Sprite Can";
const String mlPrice ="325ml, Price";
const String dietCoke ="Diet Coke";
const String appleGrapeJuice ="Apple & Grape Juice";
const String lPrice ="2L, Price";
const String cocaColaCan ="Coca Cola Can";
const String  pepsiCan ="Pepsi Can"; 

const String checkout = "Checkout";
const String delivery ="Delivery";
const String selectMethod ="Select Method";
const String pament ="Pament";
const String promoCode ="Promo Code";
const String totalCost ="Total Cost";
const String pickDiscount ="Pick discount";
const String policy ="By placing an order you agree to our";
const String terms = "Terms";
const String conditions='Conditions';
const String placeOrder ="Place Order";


//Order Place Screen
const String yourOrderHasBeen= "Your Order has been";
const String  accepted = " accepted";
const String disOfOrder = "Your items has been placcd and is on";
const String disOfOrder_ = "it’s way to being processed";
const String trackOrder ="Track Order";
const String backToHome ="Back to home"; 

//profile Screen
const String name = "Afsar Hossen";
const String mailId ="Imshuvo97@gmail.com";
const String orders ="Orders";
const String myDetails ="My Details";
const String deliveryAddress ="Delivery Address";
const String  paymentMethods ="Payment Methods";
const String  promoCord ="Promo Cord";
const String notifecations ="Notifecations";
const String  help ="Help";
const String about ="About";
const String logOut ="Log Out";