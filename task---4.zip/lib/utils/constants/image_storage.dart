class ImageStorage {
  static _Icons icons = _Icons();
  static _Images images = _Images();
}

class _Icons {
  final String googleLogo = 'assets/icons/google_logo.png';
  final String homeIcon = "assets/icons/homeIcon.svg";
  final String cartIcon = "assets/icons/cartIcon.svg";
  final String favIcon = "assets/icons/favIcon.svg";
  final String personIcon = "assets/icons/personIcon.svg";
  final String searchIcon = "assets/icons/searchIcon.svg";
  final String about = "assets/icons/about.svg";
  final String back = "assets/icons/back.svg";
  final String detail = "assets/icons/detail.svg";
  final String edit = "assets/icons/edit.svg";
  final String help = "assets/icons/help.svg";
  final String location = "assets/icons/location.svg";
  final String noti = "assets/icons/noti.svg";
  final String order = "assets/icons/order.svg";
  final String payment = "assets/icons/payment.svg";
  final String promoCode = "assets/icons/promoCode.svg";
}

class _Images {
  String logo = "assets/images/logo.png";
  String numberScreen = "assets/images/number_screen.png";
  String carrotColor = "assets/images/carrot_c.png";
  String carrotWhite = "assets/images/carrot_w.png";
  String welcomeScreen = "assets/images/welcome_screen.png";

  String google = "assets/images/google.png";
  String facebook = "assets/images/facebook.png";
  
  String alertTriangle = 'assets/images/alert-triangle.png';
  String loginSignupB = 'assets/images/login_signup_b.png';

  String adarak = 'assets/images/adarak.png';
  String ads = 'assets/images/ads.png';
  String apple = 'assets/images/apple.png';
  String banana = 'assets/images/banana.png';
  String chikan = 'assets/images/chikan.png';
  String chili = 'assets/images/chili.png';
  String meat = 'assets/images/meat.png';
  String rice = 'assets/images/rice.png';
  String spice = 'assets/images/spice.png';

  String appleDis = "assets/images/apple_dis.png";

  String coke ="assets/images/coke.png";
  String pepsi="assets/images/pepsi.png";
  String sprite="assets/images/sprite.png";
  String tometo ="assets/images/tometo.png";
  String cola ="assets/images/cola.png";

  String card ="assets/images/card.png";

  String orderCom ="assets/images/order_com.png";
  String backGround ="assets/images/background.png";

  String profile ="assets/images/profile.png";


}
