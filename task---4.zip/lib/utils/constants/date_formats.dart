import 'package:intl/intl.dart';

final ddMMMYYYY = DateFormat('dd MMM yyyy');
final ddMMMYYYYHHmm = DateFormat('dd MMM yyyy HH:mm');
final ddMMMYYYYHHmmss = DateFormat('dd MMM yyyy HH:mm:ss');
final hhMMss = DateFormat('HH:mm:ss');
final hhMM = DateFormat('HH:mm');
final hhMMA = DateFormat('HH:mm a');
