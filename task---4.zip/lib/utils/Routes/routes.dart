
import 'package:four_d_app/models/product_model/product_model.dart';
import 'package:four_d_app/screens/Splash_Screen/splash_screen.dart';
import 'package:get/get.dart';

import '../../screens/Auth_Screens/login_screen.dart';
import '../../screens/Auth_Screens/sign_in_screen.dart';
import '../../screens/Auth_Screens/sign_up_screen.dart';
import '../../screens/Auth_Screens/welcome_screen.dart';
import '../../screens/MainScreens/main_screen.dart';
import '../../screens/account_screen/edit_profile_screen.dart';
import '../../screens/order_place_screen/order_place_screen.dart';
import '../../screens/product_ditail_screen/product_detail_screen.dart';

class RoutesClass {
  //splash screen
  static String splash = '/';
  static String getSplashRoute() => splash;

  //welcome screen
  static String welcome = '/welcome_screen';
  static String getWelcomeScreenRoute()=> welcome;

  //signin screen
  static String signInScreen = '/sign_in_screen';
  static String getSignInScreenRoute()=>signInScreen;

  //login screen
  static String loginScreen = '/login_screen';
  static String getLoginScreenRoute() => loginScreen;

  //SignUp Screen
  static String signUpScreen = "/sign_up_screen";
  static String getSignUpScreenRoute() => signUpScreen;

  //main screen
  static String mainScreen = "/main_screen";
  static String getMainScreenRoute()=> mainScreen;

  //product detail screen
  static String productDetailScreen ="/product_detail_screen";
  static String getProductDetailScreenRoute()=>productDetailScreen;

  //Order Place Screen
  static String orderPlaceScreen = "/order_place_screen";
  static String getOrderPlaceScreenRoute()=>orderPlaceScreen;

  // Edit Profile Screen
  static String editProfileScreen = "/edit_profile_screen";
  static String getEditProfileScreenRoute()=>editProfileScreen;

 
  static List<GetPage> routes = [
    GetPage(name: splash, page: () => const SplashScreen()),

    GetPage(
        name: welcome,
        page: () => const WelcomeScreen(),
        transition: Transition.fade,
        transitionDuration: const Duration(milliseconds: 350)),

    //signin Screens
    GetPage(
        name:signInScreen,
        page: () => const SignInScreen(),
        transition: Transition.fade,
        transitionDuration: const Duration(milliseconds: 350)),

    //Login Screen
    GetPage(
        name:loginScreen,
        page: () => const LoginScreen(),
        transition: Transition.fade,
        transitionDuration: const Duration(milliseconds: 350)),

    //SignUp Screen
    GetPage(
      name: signUpScreen,
      page: () => const SignUpScreen(),
      transition: Transition.fade,
      transitionDuration: const Duration(milliseconds: 350),
    ),

    // main screen
    GetPage(
      name: mainScreen,
      page: () => const MainScreen(),
      transition: Transition.fade,
      transitionDuration: const Duration(milliseconds: 350),
    ),

    //product detail screen
    GetPage(
      name: productDetailScreen,
      page: () =>  const ProductDetailScreen(),
      transition: Transition.fade,
      transitionDuration: const Duration(milliseconds: 350)
    ),

    // Order Place Screen
    GetPage(
        name: orderPlaceScreen,
        page: () => const OrderPlaceScreen(),
        transition: Transition.fade,
        transitionDuration: const Duration(milliseconds: 350)),

    // Edit Profile Screen
    GetPage(
        name: editProfileScreen,
        page: () => const EditProfileScreen(),
        transition: Transition.fade,
        transitionDuration: const Duration(milliseconds: 350)),

    // cart
    // GetPage(
    //     name: cartScreen,
    //     page: () => const Cart(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    // favorite product screeen
    // GetPage(
    //     name: favoriteProductScreen,
    //     page: () => const FavoriteProduct(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    //Trending product
    // GetPage(
    //     name: trendingProductScreen,
    //     page: () => const TrendingProduct(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    //Help/Contact
    // GetPage(
    //     name: helpContactScreen,
    //     page: () => const HelpContact(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    //Main Screens
    //Home Screen or Main Screen
    // GetPage(
    //   name: mainScreen,
    //   page: () => const MainScreen(),
    //   transition: Transition.fade,
    //   transitionDuration: const Duration(milliseconds: 350),
    // ),

    //search Screen
    // GetPage(
    //   name: searchScreen,
    //   page: () => const SearchScreen(),
    //   transition: Transition.fade,
    //   transitionDuration: const Duration(milliseconds: 350),
    // ),

    // //Notification Screen
    // GetPage(
    //     name: notificationScreen,
    //     page: () => const NotificationScreen(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    // //Category product Screen
    // GetPage(
    //     name: categoryProductScreen,
    //     page: () => const CategoryProductScreen(),
    //     transition: Transition.fade,
    //     transitionDuration: const Duration(milliseconds: 350)),

    //     GetPage(name: dynamicLinkProductScreen, page: () => const DynamicLinkProductScreen())
  ];
}
