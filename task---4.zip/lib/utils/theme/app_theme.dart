import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:four_d_app/utils/theme/color_palette.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

mixin AppThemeMixin {
  ThemeData appTheme(BuildContext context) => ThemeData(
        scaffoldBackgroundColor: const Color(0xffffffff),
        primaryColor: ColorPalette.appColor,
        accentColor: ColorPalette.appColor,
        appBarTheme: const AppBarTheme(
            centerTitle: true,
            elevation: 0,
            color: Colors.transparent,
            systemOverlayStyle: SystemUiOverlayStyle(
              statusBarColor: Colors.white,
              statusBarIconBrightness: Brightness.dark,
              statusBarBrightness: Brightness.light,
            ),
            // systemOverlayStyle: SystemUiOverlayStyle(
            //     statusBarColor: Colors.transparent,
            //     statusBarIconBrightness: Brightness.dark),
            iconTheme: IconThemeData(
              color: Colors.black,
            ),
            titleTextStyle: TextStyle(
                color: Colors.black,
                fontSize: 22,
                fontWeight: FontWeight.w600)),
        // primarySwatch: ,
        fontFamily: GoogleFonts.roboto().fontFamily,
        
      );
}
