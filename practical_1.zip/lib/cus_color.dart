import 'package:flutter/material.dart';

class CColor {
  static const Color black = Color(0XFF010F07);

  static const Color delicolo = Color(0XFFEEA734);

  static const Color elebut = Color(0XFFEEA734);

  static const Color seetext = Color(0XFFF8B64C);

  static const Color clock = Color(0XFF5C6560);

  static const Color dollor = Color(0XFFB2B2B2);

  static const Color bodyText = Color(0XFF868686);

  static const Color unsele = Color(0XFF5D5D5D);
}
