import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class Slides1 extends StatefulWidget {
  @override
  State<Slides1> createState() => _Slides1State();
}

class _Slides1State extends State<Slides1> {
  int activeIndex = 0;

  final List<String> myImage = [
    "assets/BG-1.png",
    "assets/BG-1.png",
    "assets/BG-1.png",
    "assets/BG-1.png",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ListView(
            children: [
              CarouselSlider.builder(
                itemCount: myImage.length,
                itemBuilder: (context, index, realIndex) {
                  final firstImage = myImage[index];

                  return buildImage(firstImage, index);
                },
                options: CarouselOptions(
                  // onPageChanged: ,
                  height: 200.0,
                  enlargeCenterPage: true,
                  aspectRatio: 7 / 3,
                  autoPlay: true,
                  autoPlayCurve: Curves.fastOutSlowIn,
                  enableInfiniteScroll: true,
                  autoPlayAnimationDuration: Duration(milliseconds: 1000),
                  viewportFraction: 1.0,
                  onPageChanged: (index, reason) =>
                      setState(() => activeIndex = index),
                ),
              ),
            ],
          ),
          Positioned(
            bottom: 35,
            right: 20,
            child: buildIndicator(),
          ),
        ],
      ),
    );
  }

  Widget buildImage(String firstImage, int index) {
    return Container(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.asset(
          firstImage,
          fit: BoxFit.cover,
          width: double.infinity,
        ),
      ),
    );
  }

  Widget buildIndicator() {
    return AnimatedSmoothIndicator(
      activeIndex: activeIndex,
      count: myImage.length,
      effect: SlideEffect(
        dotColor: Colors.white.withOpacity(0.3),
        activeDotColor: Colors.white,
        dotWidth: 8.0,
        dotHeight: 5.0,
      ),
    );
  }
}
