import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:task_six/Shopping%20Screen/home_screen.dart';
import 'package:task_six/Starting%20Screens/sign_up.dart';
import 'package:task_six/main_screen.dart';
import 'package:task_six/widgets/cus_button1.dart';
import 'package:task_six/widgets/image_files.dart';

import '../Service/api_service.dart';
import '../widgets/colors.dart';

class LogIn extends StatefulWidget {
  const LogIn({Key? key}) : super(key: key);

  @override
  State<LogIn> createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  bool _isObscure = true;

  // final emailValid = RegExp(r'\S+@gmail.com');

  final passController = TextEditingController();
  final emailController = TextEditingController();

  var service = ApiServices();

  void snakBar(title) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(title)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Stack(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Image.asset(
                  ImageFiles.images.LogInBG,
                  fit: BoxFit.fill,
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: MediaQuery.of(context).size.height * 0.1),
                    Align(
                      alignment: Alignment.center,
                      child: SvgPicture.asset(ImageFiles.icons.carrotClr,
                          height: 50),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.13,
                    ),
                    const Text(
                      'Loging',
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.015,
                    ),
                    const Text(
                      'Enter your emails and password',
                      style: TextStyle(
                        fontSize: 16,
                        color: AColor.SearchHint,
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.05,
                    ),
                    const Text(
                      'Email',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AColor.SearchHint,
                      ),
                    ),
                    TextFormField(
                      controller: emailController,
                      cursorColor: AColor.themeColor,
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'enter email address',
                        hintStyle: TextStyle(
                          fontSize: 15,
                          color: AColor.grey,
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.5,
                            color: AColor.themeColor,
                          ),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.5,
                            color: AColor.numberBorder,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.0375,
                    ),
                    const Text(
                      'Password',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AColor.SearchHint,
                      ),
                    ),
                    TextFormField(
                      controller: passController,
                      obscureText: _isObscure,
                      keyboardType: TextInputType.number,
                      cursorColor: AColor.themeColor,
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                      decoration: InputDecoration(
                        hintText: 'enter password',
                        hintStyle: const TextStyle(
                          fontSize: 15,
                          color: AColor.grey,
                        ),
                        focusedBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.5,
                            color: AColor.themeColor,
                          ),
                        ),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.5,
                            color: AColor.numberBorder,
                          ),
                        ),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              _isObscure = !_isObscure;
                            });
                          },
                          icon: SvgPicture.asset(
                            ImageFiles.icons.eye,
                            color:
                                _isObscure ? AColor.SearchHint : AColor.black,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.02,
                    ),
                    const Align(
                      alignment: Alignment.topRight,
                      child: Text(
                        'Forgot Password?',
                        style: TextStyle(
                          letterSpacing: 0.5,
                          fontSize: 14,
                          color: AColor.forgot,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.035,
                    ),
                    CusButton(
                      text: "Log In",
                      onPressed: () {
                        if ((emailController.text.toString() == '') ||
                            passController.text.isEmpty) {
                          snakBar("Please enter all fields!");
                        } else if (!emailController.text
                            .toString()
                            .contains('@gmail.com')) {
                          snakBar("Please enter valid email!");
                        } else if (passController.text.length < 6) {
                          snakBar(
                              "password should be gretter than six digits!");
                        } else {
                          try {
                            service.logInAPI({
                              'email': emailController.text.toString(),
                              'password': passController.text.toString(),
                            }).then((value) async {
                              snakBar('Login Successfully');
                              final prefs =
                                  await SharedPreferences.getInstance();
                              prefs.setBool('isLog', true);
                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => MainScreen(),
                                  ),
                                  (route) => false);
                            }).catchError((error) {
                              snakBar(error.toString());
                            });
                          } catch (e) {
                            snakBar(e.toString());
                          }
                        }
                      },
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.029,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Don’t have an account? ',
                          style: TextStyle(
                            letterSpacing: 1,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AColor.forgot,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => SignUp(),
                                ));
                          },
                          child: const Text(
                            'Singup',
                            style: TextStyle(
                              letterSpacing: 1.2,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AColor.themeColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
