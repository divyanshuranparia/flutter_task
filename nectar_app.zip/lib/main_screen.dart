import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:task_six/Other%20Screens/acc_screen.dart';
import 'package:task_six/Other%20Screens/cart_screen.dart';
import 'package:task_six/Other%20Screens/fav_screen.dart';
import 'package:task_six/Shopping%20Screen/home_screen.dart';
import 'package:task_six/widgets/colors.dart';
import 'package:task_six/widgets/image_files.dart';

import 'Shopping Screen/explore_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  PageController _pageController = PageController(initialPage: 0);
  // final screens = [
  //   HomeScreen(),
  //   ExploreScreen(),
  //   CartScreen(),
  //   FavScreen(),
  //   AccScreen(),
  // ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        children: [
          HomeScreen(),
          ExploreScreen(),
          CartScreen(),
          FavScreen(),
          AccScreen(),
        ],
      ),
      bottomNavigationBar: cusBNB(),
    );
  }

  Widget cusBNB() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: AColor.themeColor,
      unselectedItemColor: AColor.forgot,
      selectedFontSize: 10,
      unselectedFontSize: 10,
      items: [
        BottomNavigationBarItem(
          label: 'Shop',
          icon: SvgPicture.asset(
            ImageFiles.icons.shop,
            color: _selectedIndex == 0 ? AColor.themeColor : AColor.forgot,
          ),
        ),
        BottomNavigationBarItem(
          label: 'Explore',
          icon: SvgPicture.asset(
            ImageFiles.icons.explore,
            color: _selectedIndex == 1 ? AColor.themeColor : AColor.forgot,
          ),
        ),
        BottomNavigationBarItem(
          label: 'Cart',
          icon: SvgPicture.asset(
            ImageFiles.icons.cart,
            color: _selectedIndex == 2 ? AColor.themeColor : AColor.forgot,
          ),
        ),
        BottomNavigationBarItem(
          label: 'Favourite',
          icon: SvgPicture.asset(
            ImageFiles.icons.fav,
            color: _selectedIndex == 3 ? AColor.themeColor : AColor.forgot,
          ),
        ),
        BottomNavigationBarItem(
          label: 'Account',
          icon: SvgPicture.asset(
            ImageFiles.icons.acc,
            color: _selectedIndex == 4 ? AColor.themeColor : AColor.forgot,
          ),
        ),
      ],
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _pageController.animateToPage(index,
          duration: Duration(milliseconds: 500), curve: Curves.linear);
    });
  }
}
