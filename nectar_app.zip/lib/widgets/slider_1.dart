import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:task_six/widgets/image_files.dart';

import 'colors.dart';

class Slides1 extends StatefulWidget {
  @override
  State<Slides1> createState() => _SlidesState1();
}

class _SlidesState1 extends State<Slides1> {
  int activeIndex = 0;

  final List<String> myImage = [
    ImageFiles.images.HomeBanner,
    ImageFiles.images.HomeBanner,
    ImageFiles.images.HomeBanner,
  ];
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CarouselSlider.builder(
          itemCount: myImage.length,
          itemBuilder: (context, index, realIndex) {
            final firstImage = myImage[index];

            return buildImage(firstImage, index);
          },
          options: CarouselOptions(
            // onPageChanged: ,

            enlargeCenterPage: true,
            aspectRatio: 7 / 3,
            //autoPlay: true,
            autoPlayCurve: Curves.fastOutSlowIn,
            enableInfiniteScroll: true,
            //autoPlayAnimationDuration: Duration(milliseconds: 1000),
            viewportFraction: 1.0,
            onPageChanged: (index, reason) =>
                setState(() => activeIndex = index),
          ),
        ),
        Positioned(
          bottom: 30,
          right: MediaQuery.of(context).size.width * 0.38,
          child: buildIndicator(),
        ),
      ],
    );
  }

  Widget buildImage(String firstImage, int index) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
      ),
      width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height,
      child: Image.asset(
        myImage[index],
        fit: BoxFit.fitWidth,
      ),
    );
  }

  Widget buildIndicator() {
    return AnimatedSmoothIndicator(
      activeIndex: activeIndex,
      count: myImage.length,
      effect: ExpandingDotsEffect(
        dotColor: AColor.bannerDot.withOpacity(0.3),
        activeDotColor: AColor.themeColor,
        dotWidth: 5.3,
        dotHeight: 5.3,
      ),
    );
  }
}
