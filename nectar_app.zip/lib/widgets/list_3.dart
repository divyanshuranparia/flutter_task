import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_six/widgets/image_files.dart';

import '../models/product_model.dart';
import 'colors.dart';

class List3 extends StatefulWidget {
  List<CartModel> cartModel;
  List3({Key? key, required this.cartModel}) : super(key: key);

  @override
  State<List3> createState() => _List3State();
}

class _List3State extends State<List3> {
  int count = 1;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: widget.cartModel.length,
        itemBuilder: (BuildContext context, int index) {
          return Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.135,
                child: Row(
                  children: [
                    Container(
                      width: 90,
                      height: 80,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(widget.cartModel[index].img),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                widget.cartModel[index].title,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.1,
                                  color: AColor.forgot,
                                ),
                              ),
                              SvgPicture.asset(
                                ImageFiles.icons.cross,
                                color: AColor.exit,
                              ),
                            ],
                          ),
                          SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.005),
                          Row(
                            children: [
                              Text(
                                widget.cartModel[index].quantity,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: AColor.SearchHint,
                                ),
                              ),
                              Text(
                                'price',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: AColor.SearchHint,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.03,
                          ),
                          Row(
                            children: [
                              counter(),
                              Spacer(),
                              Text(
                                widget.cartModel[index].price,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.1,
                                  color: AColor.forgot,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.005,
              ),
              Divider(
                thickness: 1,
                color: AColor.cardBorder.withOpacity(0.7),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.005,
              ),
            ],
          );
        });
  }

  Widget counter() {
    return Row(
      children: [
        InkWell(
          onTap: () {
            if (count > 1) {
              setState(() {
                count--;
              });
            }
          },
          child: Container(
            height: 43,
            width: 43,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: AColor.cardBorder, width: 1),
            ),
            child: Center(
              child: Icon(
                Icons.remove,
                color: AColor.exit,
                size: 25,
              ),
            ),
          ),
        ),
        SizedBox(
          width: 13,
        ),
        Text(
          count.toString(),
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            letterSpacing: 0.1,
            color: AColor.forgot,
          ),
        ),
        SizedBox(
          width: 13,
        ),
        InkWell(
          onTap: () {
            setState(() {
              count++;
            });
          },
          child: Container(
            height: 43,
            width: 43,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17),
              border: Border.all(color: AColor.cardBorder, width: 1),
            ),
            child: Center(
              child: Icon(
                Icons.add,
                color: AColor.themeColor,
                size: 25,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
