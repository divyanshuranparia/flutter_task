import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../models/product_model.dart';
import 'colors.dart';
import 'image_files.dart';

class List4 extends StatefulWidget {
  List<CartModel> cartModel;
  List4({Key? key, required this.cartModel}) : super(key: key);

  @override
  State<List4> createState() => _List4State();
}

class _List4State extends State<List4> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: widget.cartModel.length,
        itemBuilder: (BuildContext context, int index) {
          return Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.1,
                child: Row(
                  children: [
                    Container(
                      width: 90,
                      height: 80,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(widget.cartModel[index].img),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Expanded(
                      child: Row(
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.cartModel[index].title,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.1,
                                  color: AColor.forgot,
                                ),
                              ),
                              SizedBox(
                                  height: MediaQuery.of(context).size.height *
                                      0.005),
                              Row(
                                children: [
                                  Text(
                                    widget.cartModel[index].quantity,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: AColor.SearchHint,
                                    ),
                                  ),
                                  Text(
                                    'price',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: AColor.SearchHint,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Spacer(),
                          Text(
                            widget.cartModel[index].price,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.1,
                              color: AColor.forgot,
                            ),
                          ),
                          SizedBox(
                              width: MediaQuery.of(context).size.width * 0.02),
                          SvgPicture.asset(ImageFiles.icons.forward),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.005,
              ),
              Divider(
                thickness: 1,
                color: AColor.cardBorder.withOpacity(0.7),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.005,
              ),
            ],
          );
        });
  }
}
