import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:task_six/models/product_model.dart';
import 'package:task_six/widgets/image_files.dart';

import '../Shopping Screen/product_details.dart';
import '../models/get_product.dart';
import 'colors.dart';

class List1 extends StatelessWidget {
  List<Data> product;
  List1({Key? key, required this.product}) : super(key: key);

  String baseURL = 'http://mrmodh11.pythonanywhere.com';

  // final myImg = [
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: product.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: EdgeInsets.only(right: 11.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.45,
              child: Card(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 1,
                    color: AColor.cardBorder,
                  ),
                  borderRadius: BorderRadius.circular(18),
                ),
                elevation: 0.0,
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 15, horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ProdDetails(),
                              ));
                        },
                        child: Center(
                          child: Container(
                            width: 90,
                            height: 80,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: NetworkImage(baseURL +
                                    product[index]
                                        .product_images![0]
                                        .productImage
                                        .toString()),

                                //AssetImage(data[index].product_images),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.025,
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ProdDetails(),
                              ));
                        },
                        child: Text(
                          product[index].product_name.toString(),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: AColor.forgot,
                            letterSpacing: 0.1,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.01,
                      ),
                      // RichText(
                      //   text: TextSpan(
                      //     text: product[index].product_dic.toString(),
                      //     style: const TextStyle(
                      //       fontSize: 14,
                      //       color: AColor.SearchHint,
                      //     ),
                      //     children: [
                      //       TextSpan(
                      //         text: 'Priceg',
                      //       ),
                      //     ],
                      //   ),
                      // ),
                      Text(
                        product[index].product_dic.toString(),
                        style: TextStyle(
                          overflow: TextOverflow.ellipsis,
                          fontSize: 14,
                          color: AColor.SearchHint,
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.03,
                      ),
                      Row(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "₹ ",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: AColor.forgot,
                              letterSpacing: 0.1,
                            ),
                          ),
                          Text(
                            product[index].product_price.toString(),
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: AColor.forgot,
                              letterSpacing: 0.1,
                            ),
                          ),
                          Spacer(),
                          InkWell(
                            onTap: () {},
                            borderRadius: BorderRadius.circular(10),
                            splashColor: AColor.grey.withOpacity(0.3),
                            highlightColor: AColor.grey.withOpacity(0.3),
                            child: Container(
                              padding: EdgeInsets.all(10),
                              height: 45,
                              width: 45,
                              decoration: BoxDecoration(
                                color: AColor.themeColor,
                                borderRadius: BorderRadius.circular(17),
                              ),
                              child: SvgPicture.asset(
                                ImageFiles.icons.plus,
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }
}
