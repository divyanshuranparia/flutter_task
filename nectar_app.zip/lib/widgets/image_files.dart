import 'package:flutter/material.dart';

class ImageFiles {
  static _Icons icons = _Icons();
  static _Images images = _Images();
}

class _Icons {
  final String splash = 'assets/Icons/splash.svg';
  final String carrot = 'assets/Icons/carrot.svg';
  final String carrotClr = 'assets/Icons/carrot_color.svg';
  final String google = 'assets/Icons/google.svg';
  final String facebook = 'assets/Icons/facebook.svg';
  final String eye = 'assets/Icons/eye.svg';
  final String location = 'assets/Icons/location.svg';
  final String search = 'assets/Icons/search.svg';
  final String plus = 'assets/Icons/plus.svg';
  final String minus = 'assets/Icons/minus.svg';
  final String shop = 'assets/Icons/shop.svg';
  final String explore = 'assets/Icons/explore.svg';
  final String cart = 'assets/Icons/cart.svg';
  final String fav = 'assets/Icons/fav.svg';
  final String acc = 'assets/Icons/acc.svg';
  final String down = 'assets/Icons/down.svg';
  final String forward = 'assets/Icons/forward.svg';
  final String back = 'assets/Icons/back.svg';
  final String upload = 'assets/Icons/upload.svg';
  final String cross = 'assets/Icons/cross.svg';
  final String about = 'assets/Icons/about.svg';
  final String detail = 'assets/Icons/detail.svg';
  final String orders = 'assets/Icons/orders.svg';
  final String loca = 'assets/Icons/loca.svg';
  final String pay = 'assets/Icons/pay.svg';
  final String promo = 'assets/Icons/promo.svg';
  final String notify = 'assets/Icons/notify.svg';
  final String help = 'assets/Icons/help.svg';
  final String logout = 'assets/Icons/logout.svg';
}

class _Images {
  final String onBoardBG = 'assets/Images/onBoardBG.png';
  final String SignBG = 'assets/Images/SignInBG.png';
  final String LogInBG = 'assets/Images/login.png';
  final String HomeBanner = 'assets/Images/homeBanner.png';
  final String apple = 'assets/Images/apple.png';
  final String banana = 'assets/Images/banana.png';
  final String redPepper = 'assets/Images/redPepper.png';
  final String ginger = 'assets/Images/ginger.png';
  final String pulses = 'assets/Images/pulses.png';
  final String rice = 'assets/Images/rice.png';
  final String beef = 'assets/Images/beef.png';
  final String chicken = 'assets/Images/chicken.png';
  final String appleBig = 'assets/Images/apple_big.png';
  final String egg = 'assets/Images/egg.png';
  final String sprite = 'assets/Images/sprite.png';
  final String coke = 'assets/Images/coke.png';
  final String coca = 'assets/Images/coca.png';
  final String juice = 'assets/Images/juice.png';
  final String pepsi = 'assets/Images/pepsi.png';
  final String card = 'assets/Images/card.png';
  final String oaBG = 'assets/Images/OA-BG.png';
  final String placed = 'assets/Images/placed.png';
  final String profile = 'assets/Images/profile.png';
}
