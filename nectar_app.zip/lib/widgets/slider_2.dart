import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'colors.dart';
import 'image_files.dart';

class Slides2 extends StatefulWidget {
  const Slides2({Key? key}) : super(key: key);

  @override
  State<Slides2> createState() => _Slides2State();
}

class _Slides2State extends State<Slides2> {
  int activeIndex = 0;

  final List<String> myImage = [
    ImageFiles.images.appleBig,
    ImageFiles.images.appleBig,
    ImageFiles.images.appleBig,
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CarouselSlider.builder(
          itemCount: myImage.length,
          itemBuilder: (context, index, realIndex) {
            final firstImage = myImage[index];

            return buildImage(firstImage, index);
          },
          options: CarouselOptions(
            // onPageChanged: ,

            enlargeCenterPage: true,
            aspectRatio: 7 / 3,
            //autoPlay: true,
            autoPlayCurve: Curves.fastOutSlowIn,
            enableInfiniteScroll: true,
            //autoPlayAnimationDuration: Duration(milliseconds: 1000),
            viewportFraction: 1.0,
            onPageChanged: (index, reason) =>
                setState(() => activeIndex = index),
          ),
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.05,
        ),
        buildIndicator(),
      ],
    );
  }

  Widget buildImage(String firstImage, int index) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
      ),
      width: MediaQuery.of(context).size.width,
      //height: MediaQuery.of(context).size.height,
      child: Image.asset(
        myImage[index],
        fit: BoxFit.fitHeight,
      ),
    );
  }

  Widget buildIndicator() {
    return AnimatedSmoothIndicator(
      activeIndex: activeIndex,
      count: myImage.length,
      effect: ExpandingDotsEffect(
        dotColor: AColor.bannerDot.withOpacity(0.3),
        activeDotColor: AColor.themeColor,
        dotWidth: 4.5,
        dotHeight: 4.5,
      ),
    );
  }
}

//FOR PRODUCT DETAILS
