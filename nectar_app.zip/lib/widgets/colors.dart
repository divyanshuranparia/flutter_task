import 'package:flutter/material.dart';

class AColor {
  static const Color themeColor = Color(0XFF53B175);

  static const Color white = Color(0XFFFFFFFF);

  static const Color black = Color(0XFF000000);

  static const Color grey = Color(0XFF808080);

  static const Color HomeSearch = Color(0XFFF2F3F2);

  static const Color SearchHint = Color(0XFF7C7C7C);

  static const Color numberBorder = Color(0XFFE2E2E2);

  static const Color googlebut = Color(0XFF5383EC);

  static const Color facebookbut = Color(0XFF4A66AC);

  static const Color forgot = Color(0XFF181725);

  static const Color place = Color(0XFF4C4F4D);

  static const Color location = Color(0XFF393636);

  static const Color bannerDot = Color(0XFF030303);

  static const Color cardBorder = Color(0XFFE2E2E2);

  static const Color pulses = Color(0XFFF8A44C);

  static const Color groceryText = Color(0XFF3E423F);

  static const Color pdShadow = Color(0XFFEBEBEB);

  static const Color rateStar = Color(0XFFF3603F);

  static const Color red = Color(0XFFFF0000);

  static const Color exit = Color(0XFFB3B3B3);
}
