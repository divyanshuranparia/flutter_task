import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../models/product_model.dart';
import 'colors.dart';

class List2 extends StatelessWidget {
  List<GroceriesModel> groceryModel;
  List2({Key? key, required this.groceryModel}) : super(key: key);

  // final myImg = [
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: groceryModel.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.only(right: 11.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.6,
              decoration: BoxDecoration(
                color: groceryModel[index].color,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                children: [
                  SizedBox(width: MediaQuery.of(context).size.width * 0.05),
                  Image.asset(groceryModel[index].img),
                  SizedBox(width: MediaQuery.of(context).size.width * 0.04),
                  Text(
                    groceryModel[index].title,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: AColor.groceryText,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
