import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'colors.dart';

class CusButton extends StatelessWidget {
  final String text;
  final Function() onPressed;

  CusButton({
    Key? key,
    required this.text,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: InkWell(
        onTap: onPressed,
        child: Container(
          height: MediaQuery.of(context).size.height * 0.07,
          width: MediaQuery.of(context).size.width * 0.85,
          decoration: BoxDecoration(
            color: AColor.themeColor,
            borderRadius: BorderRadius.circular(19),
          ),
          child: Align(
            alignment: Alignment.center,
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: AColor.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
