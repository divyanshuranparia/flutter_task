import 'dart:ui';

import 'package:task_six/widgets/colors.dart';

import '../widgets/image_files.dart';

class ProductModel {
  String img;
  String title;
  String quantity;

  ProductModel({
    required this.img,
    required this.title,
    required this.quantity,
  });
}

List<ProductModel> exclusiveOffer = [
  ProductModel(
    img: ImageFiles.images.banana,
    title: 'Organic Bananas',
    quantity: "7pcs, ",
  ),
  ProductModel(
    img: ImageFiles.images.apple,
    title: 'Red Apple',
    quantity: "1kg, ",
  ),
  ProductModel(
    img: ImageFiles.images.banana,
    title: 'Organic Bananas',
    quantity: "7pcs, ",
  ),
];

List<ProductModel> bestSelling = [
  ProductModel(
    img: ImageFiles.images.redPepper,
    title: 'Bell Pepper Red',
    quantity: "1kg, ",
  ),
  ProductModel(
    img: ImageFiles.images.ginger,
    title: 'Ginger',
    quantity: "250gm, ",
  ),
  ProductModel(
    img: ImageFiles.images.redPepper,
    title: 'Bell Pepper Red',
    quantity: "1kg, ",
  ),
];

List<ProductModel> nonVeg = [
  ProductModel(
    img: ImageFiles.images.beef,
    title: 'Beef Bone',
    quantity: "1kg, ",
  ),
  ProductModel(
    img: ImageFiles.images.chicken,
    title: 'Broiler Chicken',
    quantity: "250gm, ",
  ),
  ProductModel(
    img: ImageFiles.images.beef,
    title: 'Beef Bone',
    quantity: "1kg, ",
  ),
];

//Grocery
class GroceriesModel {
  String img;
  String title;
  Color color;

  GroceriesModel({
    required this.img,
    required this.title,
    required this.color,
  });
}

List<GroceriesModel> groceriesList = [
  GroceriesModel(
    img: ImageFiles.images.pulses,
    title: 'Pulses',
    color: AColor.pulses.withOpacity(0.15),
  ),
  GroceriesModel(
    img: ImageFiles.images.rice,
    title: 'Rice',
    color: AColor.themeColor.withOpacity(0.15),
  )
];

class CartModel {
  String img;
  String title;
  String quantity;
  String price;

  CartModel({
    required this.img,
    required this.title,
    required this.quantity,
    required this.price,
  });
}

List<CartModel> myCart = [
  CartModel(
    img: ImageFiles.images.redPepper,
    title: 'Bell Pepper Red',
    quantity: "1kg, ",
    price: "\$4.99",
  ),
  CartModel(
    img: ImageFiles.images.egg,
    title: 'Egg Chicken Red',
    quantity: "4pcs, ",
    price: "\$1.99",
  ),
  CartModel(
    img: ImageFiles.images.banana,
    title: 'Organic Bananas',
    quantity: "12kg, ",
    price: "\$3.00",
  ),
  CartModel(
    img: ImageFiles.images.ginger,
    title: 'Ginger',
    quantity: "250gm, ",
    price: "\$2.99",
  ),
];

List<CartModel> myFav = [
  CartModel(
    img: ImageFiles.images.sprite,
    title: 'Sprite Can',
    quantity: "325ml, ",
    price: "\$1.50",
  ),
  CartModel(
    img: ImageFiles.images.coke,
    title: 'Diet Coke',
    quantity: "355ml, ",
    price: "\$1.99",
  ),
  CartModel(
    img: ImageFiles.images.juice,
    title: 'Apple & Grape Juice',
    quantity: "2L, ",
    price: "\$15.50",
  ),
  CartModel(
    img: ImageFiles.images.coca,
    title: 'Coca Cola Can',
    quantity: "325ml, ",
    price: "\$4.99",
  ),
  CartModel(
    img: ImageFiles.images.pepsi,
    title: 'Pepsi Can ',
    quantity: "330ml, ",
    price: "\$4.99",
  ),
];
