class LogUser {
  final int? status;
  final String? message;
  final Data? data;

  LogUser({
    this.status,
    this.message,
    this.data,
  });

  LogUser.fromJson(Map<String, dynamic> json)
      : status = json['status'] as int?,
        message = json['message'] as String?,
        data = (json['data'] as Map<String, dynamic>?) != null
            ? Data.fromJson(json['data'] as Map<String, dynamic>)
            : null;

  Map<String, dynamic> toJson() =>
      {'status': status, 'message': message, 'data': data?.toJson()};
}

class Data {
  // final bool? isSuperuser;
  // final bool? isStaff;
  final bool? isActive;
  final String? firstName;
  final String? lastName;
  final String? email;
  final String? password;
  final String? profileImage;
  // final List<dynamic>? groups;
  // final List<dynamic>? userPermissions;

  Data({
    // this.isSuperuser,
    // this.isStaff,
    this.isActive,
    this.firstName,
    this.lastName,
    this.email,
    this.password,
    this.profileImage,
    // this.groups,
    // this.userPermissions,
  });

  Data.fromJson(Map<String, dynamic> json)
      :
        // isSuperuser = json['is_superuser'] as bool?,
        //   isStaff = json['is_staff'] as bool?,
        isActive = json['is_active'] as bool?,
        firstName = json['first_name'] as String?,
        lastName = json['last_name'] as String?,
        email = json['email'] as String?,
        password = json['password'] as String?,
        profileImage = json['profile_image'] as String?;
  // groups = json['groups'] as List?,
  // userPermissions = json['user_permissions'] as List?;

  Map<String, dynamic> toJson() => {
        // 'is_superuser': isSuperuser,
        // 'is_staff': isStaff,
        'is_active': isActive,
        'first_name': firstName,
        'last_name': lastName,
        'email': email,
        'password': password,
        'profile_image': profileImage,
        // 'groups': groups,
        // 'user_permissions': userPermissions
      };
}
