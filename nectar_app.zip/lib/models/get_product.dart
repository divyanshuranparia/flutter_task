import 'package:flutter/foundation.dart';
import 'package:task_six/models/log_user.dart';

class GetProduct {
  String status;
  String message;
  List<Data> data;

  GetProduct({
    required this.status,
    required this.message,
    required this.data,
  });

  factory GetProduct.fromJson(Map<String, dynamic> json) {
    return GetProduct(
        message: json['message'],
        status: json['status'].toString(),
        data: (json['data'] as List).map((e) => Data.fromJson(e)).toList());
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'status': status,
      'data': data.map((e) => e.toJson()).toList(),
    };
  }
}

class Data {
  int? id;
  String? product_name;
  String? product_dic;
  double? product_price;
  double? product_discount_price;
  String? product_type;
  List<ProductImages>? product_images;

  Data({
    this.id,
    this.product_name,
    this.product_dic,
    this.product_price,
    this.product_discount_price,
    this.product_type,
    this.product_images,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    product_name = json['product_name'];
    product_dic = json['product_dic'];
    product_price = json['product_price'];
    product_discount_price = json['product_discount_price'];
    product_type = json['product_type'];
    product_images = (json['product_images'] as List)
        .map((e) => ProductImages.fromJson(e))
        .toList();
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'product_name': product_name,
        'product_images': product_images?.map((e) => e.toJson()).toList(),
        'product_dic': product_dic,
        'product_price': product_price,
        'product_discount_price': product_discount_price,
        'product_type': product_type
      };
}

class ProductImages {
  String? productImage;

  ProductImages({
    this.productImage,
  });

  ProductImages.fromJson(Map<String, dynamic> json) {
    productImage = json['product_image'];
  }
  Map<String, dynamic> toJson() {
    return {
      'productImage': productImage,
    };
  }
}
