import 'package:http/http.dart' as http;
import 'package:task_six/models/get_product.dart';
import 'dart:convert' as convert;

import 'package:task_six/models/log_user.dart';

class ApiServices {
  Future<LogUser> signUpAPI(Map<String, dynamic> param) async {
    var url = Uri.parse('http://mrmodh11.pythonanywhere.com/userRegestration');
    var result = await http.post(url, body: param);
    if (result.statusCode == 200) {
      final data = convert.jsonDecode(result.body);
      if (data['message'] == "user is already exists" || data['status'] == 0) {
        throw "user is already exists";
      } else if (data['status'] == '0') {
        throw "data is not uploaded";
      } else {
        LogUser resultModel = LogUser.fromJson(data);
        return resultModel;
      }
    } else {
      throw 'fail to upload data';
    }
  }

  Future<LogUser> logInAPI(Map<String, dynamic> param) async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/userLogin");
    var result = await http.post(url, body: param);
    if (result.statusCode == 200) {
      final data = convert.jsonDecode(result.body);
      if (data['message'] == "user not found" || data['status'] == 0) {
        throw "user not found";
      } else if (data['status'] == '0') {
        throw "data is not uploaded";
      } else {
        LogUser resultModel = LogUser.fromJson(data);
        return resultModel;
      }
    } else {
      throw 'fail to login';
    }
  }

  Future<GetProduct> getData() async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/getProduct");
    var result = await http.get(url);
    if (result.statusCode == 200) {
      final data = convert.jsonDecode(result.body);

      GetProduct getProductModel = GetProduct.fromJson(data);
      return getProductModel;
    } else {
      throw result.body;
    }
  }
}
