import 'package:flutter/material.dart';
import 'package:task_six/Shopping%20Screen/home_screen.dart';
import 'package:task_six/main_screen.dart';
import 'package:task_six/widgets/colors.dart';
import 'package:task_six/widgets/image_files.dart';

class OrderAcpt extends StatelessWidget {
  const OrderAcpt({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Image.asset(
                ImageFiles.images.oaBG,
                fit: BoxFit.fill,
              ),
            ),
            Center(
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.15,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 30.0),
                    child: Image.asset(ImageFiles.images.placed),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.1,
                  ),
                  Text(
                    'Your Order has been',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w600,
                      color: AColor.forgot,
                    ),
                  ),
                  Text(
                    'accepted',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w600,
                      color: AColor.forgot,
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.03,
                  ),
                  Text(
                    'Your items has been placcd and is on',
                    style: TextStyle(
                      fontSize: 16,
                      color: AColor.SearchHint,
                    ),
                  ),
                  Text(
                    'it’s way to being processed',
                    style: TextStyle(
                      fontSize: 16,
                      color: AColor.SearchHint,
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.1,
                  ),
                  Center(
                    child: InkWell(
                      onTap: () {},
                      borderRadius: BorderRadius.circular(10),
                      splashColor: AColor.grey.withOpacity(0.3),
                      highlightColor: AColor.grey.withOpacity(0.3),
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.07,
                        width: MediaQuery.of(context).size.width * 0.87,
                        decoration: BoxDecoration(
                          color: AColor.themeColor,
                          borderRadius: BorderRadius.circular(19),
                        ),
                        child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            'Track Order',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: AColor.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.02,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MainScreen(),
                          ),
                          (route) => false);
                    },
                    child: Text(
                      'Back to home',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: AColor.forgot,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
