import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:task_six/Starting%20Screens/log_in.dart';
import 'package:task_six/widgets/colors.dart';
import 'package:task_six/widgets/image_files.dart';

class AccScreen extends StatelessWidget {
  const AccScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 25.0, top: 70),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(27),
                    child: Image.asset(
                      ImageFiles.images.profile,
                      fit: BoxFit.fill,
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.05,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Afsar Hossen',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: AColor.forgot,
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.02,
                          ),
                          Icon(
                            Icons.edit_outlined,
                            color: AColor.themeColor,
                          ),
                        ],
                      ),
                      Text(
                        'Imshuvo97@gmail.com',
                        style: TextStyle(
                          fontSize: 16,
                          color: AColor.SearchHint,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.03,
            ),
            cusTab(context, ImageFiles.icons.orders, 'Orders'),
            cusTab(context, ImageFiles.icons.detail, 'My Details'),
            cusTab(context, ImageFiles.icons.loca, 'Delivery Address'),
            cusTab(context, ImageFiles.icons.pay, 'Payment Methods'),
            cusTab(context, ImageFiles.icons.promo, 'Promo Cord'),
            cusTab(context, ImageFiles.icons.notify, 'Notifecations'),
            cusTab(context, ImageFiles.icons.help, 'Help'),
            cusTab(context, ImageFiles.icons.about, 'About'),
            Divider(
              thickness: 1,
              color: AColor.cardBorder,
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.05,
            ),
            Center(
              child: InkWell(
                onTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  prefs.remove('isLog');
                  Navigator.pushAndRemoveUntil(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                    return LogIn();
                  }), (route) => false);
                },
                borderRadius: BorderRadius.circular(10),
                splashColor: AColor.grey.withOpacity(0.3),
                highlightColor: AColor.grey.withOpacity(0.3),
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.07,
                  width: MediaQuery.of(context).size.width * 0.87,
                  decoration: BoxDecoration(
                    color: AColor.HomeSearch,
                    borderRadius: BorderRadius.circular(19),
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.07,
                        ),
                        SvgPicture.asset(ImageFiles.icons.logout),
                        Spacer(),
                        Text(
                          'Log Out',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AColor.themeColor,
                          ),
                        ),
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.35,
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.05,
            ),
          ],
        ),
      ),
    );
  }

  Widget cusTab(BuildContext ctx, iconPath, String title) {
    return Column(
      children: [
        Divider(
          thickness: 1,
          color: AColor.cardBorder,
        ),
        SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.02,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Row(
            children: [
              Row(
                children: [
                  SvgPicture.asset(
                    iconPath.toString(),
                    color: AColor.forgot,
                  ),
                  SizedBox(
                    width: MediaQuery.of(ctx).size.width * 0.05,
                  ),
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: AColor.forgot,
                    ),
                  ),
                ],
              ),
              Spacer(),
              SvgPicture.asset(
                ImageFiles.icons.forward,
                color: AColor.forgot,
              ),
            ],
          ),
        ),
        SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.02,
        ),
      ],
    );
  }
}
