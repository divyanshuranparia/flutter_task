import 'package:flutter/material.dart';
import 'package:task_six/models/product_model.dart';

import '../widgets/colors.dart';
import '../widgets/list_4.dart';
import 'cart_screen.dart';

class FavScreen extends StatefulWidget {
  const FavScreen({Key? key}) : super(key: key);

  @override
  State<FavScreen> createState() => _FavScreenState();
}

class _FavScreenState extends State<FavScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.3,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          'Favorurite',
          style: TextStyle(
            fontSize: 18,
            color: AColor.forgot,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Container(
          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 15),
          child: Stack(
            children: [
              List4(cartModel: myFav),
              Positioned(
                bottom: 0,
                child: Center(
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CartScreen(),
                          ));
                    },
                    borderRadius: BorderRadius.circular(10),
                    splashColor: AColor.grey.withOpacity(0.3),
                    highlightColor: AColor.grey.withOpacity(0.3),
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.07,
                      width: MediaQuery.of(context).size.width * 0.87,
                      decoration: BoxDecoration(
                        color: AColor.themeColor,
                        borderRadius: BorderRadius.circular(19),
                      ),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Add All To Cart',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AColor.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}
