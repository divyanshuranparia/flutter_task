import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_six/Other%20Screens/order_accept.dart';
import 'package:task_six/widgets/colors.dart';
import 'package:task_six/widgets/image_files.dart';
import 'package:task_six/widgets/list_3.dart';

import '../models/product_model.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.3,
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          'My Cart',
          style: TextStyle(
            fontSize: 18,
            color: AColor.forgot,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 15),
        child: Stack(
          children: [
            List3(cartModel: myCart),
            Positioned(
              bottom: 70,
              child: Center(
                child: InkWell(
                  onTap: () {
                    setState(() {
                      BottomSheet();
                    });
                  },
                  borderRadius: BorderRadius.circular(10),
                  splashColor: AColor.grey.withOpacity(0.3),
                  highlightColor: AColor.grey.withOpacity(0.3),
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.07,
                    width: MediaQuery.of(context).size.width * 0.87,
                    decoration: BoxDecoration(
                      color: AColor.themeColor,
                      borderRadius: BorderRadius.circular(19),
                    ),
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        'Go to Checkout',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: AColor.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future BottomSheet() {
    return showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      builder: (BuildContext context) {
        return Container(
          decoration: BoxDecoration(
            color: AColor.white,
            borderRadius: BorderRadius.only(
              topRight: Radius.circular(30),
              topLeft: Radius.circular(30),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24.0, vertical: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Checkout',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: AColor.forgot,
                        ),
                      ),
                      SvgPicture.asset(
                        ImageFiles.icons.cross,
                        color: AColor.forgot,
                      ),
                    ],
                  ),
                ),
                Divider(
                  thickness: 1,
                  color: AColor.cardBorder.withOpacity(0.7),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 10),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          cusText('Delivery'),
                          Spacer(),
                          Row(
                            children: [
                              cusText2('Select Method'),
                              SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.03),
                              SvgPicture.asset(ImageFiles.icons.forward),
                            ],
                          ),
                        ],
                      ),
                      cusDivider(),
                      Row(
                        children: [
                          cusText('Payment'),
                          Spacer(),
                          Row(
                            children: [
                              Image.asset(ImageFiles.images.card),
                              SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.03),
                              SvgPicture.asset(ImageFiles.icons.forward),
                            ],
                          ),
                        ],
                      ),
                      cusDivider(),
                      Row(
                        children: [
                          cusText('Promo Code'),
                          Spacer(),
                          Row(
                            children: [
                              cusText2('Pick discount'),
                              SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.03),
                              SvgPicture.asset(ImageFiles.icons.forward),
                            ],
                          ),
                        ],
                      ),
                      cusDivider(),
                      Row(
                        children: [
                          cusText('Total Cost'),
                          Spacer(),
                          Row(
                            children: [
                              cusText2('\$13.97'),
                              SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width * 0.03),
                              SvgPicture.asset(ImageFiles.icons.forward),
                            ],
                          ),
                        ],
                      ),
                      cusDivider(),
                      RichText(
                        text: TextSpan(
                          text: 'By placing an order you agree to our ',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: AColor.SearchHint,
                          ),
                          children: const <TextSpan>[
                            TextSpan(
                              text: 'Terms ',
                              style: TextStyle(
                                color: AColor.forgot,
                              ),
                            ),
                            TextSpan(text: 'And '),
                            TextSpan(
                              text: 'Conditions.',
                              style: TextStyle(
                                color: AColor.forgot,
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.020,
                      ),
                      Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => OrderAcpt(),
                                ));
                          },
                          borderRadius: BorderRadius.circular(10),
                          splashColor: AColor.grey.withOpacity(0.3),
                          highlightColor: AColor.grey.withOpacity(0.3),
                          child: Container(
                            height: MediaQuery.of(context).size.height * 0.07,
                            width: MediaQuery.of(context).size.width * 0.87,
                            decoration: BoxDecoration(
                              color: AColor.themeColor,
                              borderRadius: BorderRadius.circular(19),
                            ),
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                'Place Order',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: AColor.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.020,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget cusText(String data) {
    return Text(
      data,
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: AColor.SearchHint,
      ),
    );
  }

  Widget cusText2(String data) {
    return Text(
      data,
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: AColor.forgot,
      ),
    );
  }

  Widget cusDivider() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.020,
        ),
        Divider(
          thickness: 1,
          color: AColor.cardBorder.withOpacity(0.7),
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.020,
        ),
      ],
    );
  }
}
