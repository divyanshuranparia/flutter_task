import 'package:flutter/material.dart';
import 'package:task_six/widgets/colors.dart';

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          'Comming Soon...',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: AColor.themeColor,
          ),
        ),
      ),
    );
  }
}
