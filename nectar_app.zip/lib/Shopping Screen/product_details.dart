import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_six/Other%20Screens/cart_screen.dart';
import 'package:task_six/widgets/image_files.dart';
import 'package:task_six/widgets/slider_2.dart';

import '../widgets/colors.dart';

class ProdDetails extends StatefulWidget {
  const ProdDetails({Key? key}) : super(key: key);

  @override
  State<ProdDetails> createState() => _ProdDetailsState();
}

class _ProdDetailsState extends State<ProdDetails> {
  int count = 1;
  bool isDown = true;
  bool isFav = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.45,
                decoration: BoxDecoration(
                  color: AColor.HomeSearch,
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 10.0,
                      ),
                      child: Row(
                        children: [
                          SvgPicture.asset(ImageFiles.icons.back),
                          Spacer(),
                          SvgPicture.asset(
                            ImageFiles.icons.upload,
                            color: AColor.forgot,
                          ),
                        ],
                      ),
                    ),
                    Slides2(),
                    // Image.asset(
                    //   ImageFiles.images.appleBig,
                    // ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 10.0,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.025,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Naturel Red Apple',
                          style: TextStyle(
                            //letterSpacing: 0.1,
                            fontWeight: FontWeight.bold,
                            fontSize: 24,
                            color: AColor.forgot,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              isFav = !isFav;
                            });
                          },
                          child: isFav
                              ? Icon(
                                  Icons.favorite,
                                  color: AColor.red,
                                  size: 25,
                                )
                              : SvgPicture.asset(
                                  ImageFiles.icons.fav,
                                  color: AColor.SearchHint,
                                  height: 20,
                                ),
                        ),
                      ],
                    ),
                    Text(
                      '1kg, Price',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AColor.SearchHint),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.04,
                    ),
                    Row(
                      children: [
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                if (count > 1) {
                                  setState(() {
                                    count--;
                                  });
                                }
                              },
                              child: Container(
                                height: 25,
                                width: 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(2),
                                ),
                                child: Center(
                                  child: SvgPicture.asset(
                                    ImageFiles.icons.minus,
                                    width: 17,
                                    height: 3,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Container(
                              height: 46,
                              width: 46,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(17),
                                border: Border.all(
                                    color: AColor.cardBorder, width: 1),
                              ),
                              child: Center(
                                child: Text(
                                  count.toString(),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 18,
                                    color: AColor.forgot,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  count++;
                                });
                              },
                              child: Container(
                                height: 25,
                                width: 25,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(2),
                                ),
                                child: Center(
                                  child: SvgPicture.asset(
                                    ImageFiles.icons.plus,
                                    color: AColor.themeColor,
                                    width: 17,
                                    height: 17,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Spacer(),
                        Text(
                          '\$4.99',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 24,
                            letterSpacing: 0.1,
                            color: AColor.forgot,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.035,
                    ),
                    Divider(
                      thickness: 1,
                      color: AColor.cardBorder.withOpacity(0.7),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.02,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Product Detail',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: AColor.forgot,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              isDown = !isDown;
                            });
                          },
                          child: Container(
                            height: 20,
                            width: 20,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(2),
                            ),
                            child: Center(
                              child: SvgPicture.asset(
                                isDown
                                    ? ImageFiles.icons.down
                                    : ImageFiles.icons.forward,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.02,
                    ),
                    if (isDown == true) proDetails(),
                    Divider(
                      thickness: 1,
                      color: AColor.cardBorder.withOpacity(0.7),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.015,
                    ),
                    Row(
                      children: [
                        Text(
                          'Nutritions',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: AColor.forgot,
                          ),
                        ),
                        Spacer(),
                        Row(
                          children: [
                            Container(
                              height: 20,
                              width: 35,
                              decoration: BoxDecoration(
                                color: AColor.pdShadow,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Center(
                                child: Text(
                                  '100gr',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 9,
                                    color: AColor.SearchHint,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                            SvgPicture.asset(
                              ImageFiles.icons.forward,
                              color: AColor.forgot,
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.015,
                    ),
                    Divider(
                      thickness: 1,
                      color: AColor.cardBorder.withOpacity(0.7),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.015,
                    ),
                    Row(
                      children: [
                        Text(
                          'Review',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: AColor.forgot,
                          ),
                        ),
                        Spacer(),
                        Row(
                          children: [
                            ratingBar(),
                            SizedBox(
                              width: 20,
                            ),
                            SvgPicture.asset(
                              ImageFiles.icons.forward,
                              color: AColor.forgot,
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.03,
                    ),
                    Center(
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => CartScreen(),
                              ));
                        },
                        borderRadius: BorderRadius.circular(10),
                        splashColor: AColor.grey.withOpacity(0.3),
                        highlightColor: AColor.grey.withOpacity(0.3),
                        child: Container(
                          height: MediaQuery.of(context).size.height * 0.07,
                          width: MediaQuery.of(context).size.width * 0.85,
                          decoration: BoxDecoration(
                            color: AColor.themeColor,
                            borderRadius: BorderRadius.circular(19),
                          ),
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              'Add To Basket',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: AColor.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.02,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget proDetails() {
    return Column(
      children: [
        Text(
          'Apples are nutritious. Apples may be good for weight loss. apples may be good for your heart. As part of a healtful and varied diet.',
          style: TextStyle(
            fontSize: 13,
            color: AColor.SearchHint,
          ),
          textAlign: TextAlign.justify,
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.015,
        ),
      ],
    );
  }

  Widget ratingBar() {
    return RatingBar.builder(
      glow: false,
      initialRating: 5,
      minRating: 1,
      itemSize: 20.0,
      direction: Axis.horizontal,
      itemCount: 5,
      itemBuilder: (context, _) => Icon(
        Icons.star,
        color: AColor.rateStar,
      ),
      onRatingUpdate: (rating) {},
    );
  }
}
