import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_six/widgets/colors.dart';
import 'package:task_six/widgets/image_files.dart';
import 'package:task_six/widgets/list_1.dart';
import 'package:task_six/widgets/list_2.dart';

import '../Service/api_service.dart';
import '../models/get_product.dart';
import '../models/product_model.dart';
import '../widgets/slider_1.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void snakBar(title) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(title)));
  }

  var service = ApiServices();
  List<Data> allProducts = [];
  List<Data> bestSeller = [];
  List<Data> exclusive = [];
  @override
  void initState() {
    // TODO: implement initState

    fetchData();
  }

  fetchData() {
    try {
      allProducts = [];
      bestSeller = [];
      exclusive = [];
      service.getData().then((GetProduct value) async {
        allProducts = value.data;
        for (int i = 0; i <= allProducts.length - 1; i++) {
          if (allProducts[i].product_type == 'best_seller') {
            bestSeller.add(allProducts[i]);
          } else {
            exclusive.add(allProducts[i]);
          }
        }

        // print("BEST SELLER ====$bestSeller");
        // print("EXCLUSIVE===$exclusive");
      }).catchError((error) {
        snakBar(error.toString());
      });
    } catch (e) {
      //print(e);
      snakBar(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          child: Column(
            children: [
              SizedBox(height: MediaQuery.of(context).size.height * 0.05),
              Align(
                alignment: Alignment.center,
                child: SvgPicture.asset(ImageFiles.icons.carrotClr, height: 45),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.015),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    ImageFiles.icons.location,
                    height: 18,
                    width: 15,
                  ),
                  SizedBox(
                    width: 7.44,
                  ),
                  Text(
                    'Dhaka, Banassre',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: AColor.place,
                    ),
                  ),
                ],
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.03),
              TextField(
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                    prefixIcon: SvgPicture.asset(
                      ImageFiles.icons.search,
                      height: 18.21,
                      width: 18.21,
                      fit: BoxFit.scaleDown,
                    ),
                    prefixIconColor: AColor.black,
                    hintText: 'Search store',
                    hintStyle: TextStyle(
                      color: AColor.SearchHint,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: InputBorder.none,
                    filled: true,
                    fillColor: AColor.HomeSearch,
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                          BorderSide(color: Colors.transparent), //<-- SEE HERE
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.transparent,
                      ),
                      borderRadius: BorderRadius.circular(15.0),
                    )),
              ),
              Slides1(),
              exclusive == [] ? SizedBox() : cusTitle('Exclusive Offer'),
              SizedBox(height: MediaQuery.of(context).size.height * 0.015),
              exclusive == []
                  ? SizedBox()
                  : SizedBox(
                      height: MediaQuery.of(context).size.height * 0.32,
                      child: List1(product: exclusive),
                    ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.025),
              bestSeller == [] ? SizedBox() : cusTitle('Best Selling'),
              SizedBox(height: MediaQuery.of(context).size.height * 0.015),
              bestSeller == []
                  ? SizedBox()
                  : SizedBox(
                      height: MediaQuery.of(context).size.height * 0.32,
                      child: List1(product: bestSeller),
                    ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.025),
              cusTitle('Groceries'),
              SizedBox(height: MediaQuery.of(context).size.height * 0.015),
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.12,
                child: List2(groceryModel: groceriesList),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.015),
              exclusive == []
                  ? SizedBox()
                  : SizedBox(
                      height: MediaQuery.of(context).size.height * 0.32,
                      child: List1(product: exclusive),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Widget cusTitle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: AColor.forgot,
          ),
        ),
        Text(
          'See all',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: AColor.themeColor,
          ),
        ),
      ],
    );
  }
}
