package com.example.task_six;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
