import 'package:flutter/material.dart';

class AColor {
  static const Color background = Color(0XFFECECEA);

  static const Color themeColor = Color(0XFF5857F3);

  static const Color white = Color(0XFFFFFFFF);

  static const Color black = Color(0XFF000000);

  static const Color grey = Color(0XFF808080);

  static const Color red = Color(0XFFFF0000);

  static const Color green = Color(0XFF00FF00);
}
