import 'package:flutter/material.dart';
import 'package:practical_four/Model/image_model.dart';
import 'package:practical_four/classes/color.dart';

import '../Services/api_services.dart';
import '../customs/cus_buttons.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final searchController = TextEditingController();

  void snakBar(title, color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          title,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: AColor.white,
          ),
        ),
        backgroundColor: color,
        duration: const Duration(seconds: 1),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(10),
          ),
        ),
      ),
    );
  }

  var service = ApiServices();
  List<Data> allImages = [];
  @override
  void initState() {
    // TODO: implement initState

    getImages();
  }

  getImages() {
    try {
      allImages = [];
      service.getData().then((ImageModel value) async {
        allImages = value.data;
        setState(() {});
      });
    } catch (e) {
      snakBar(e.toString(), AColor.grey.withOpacity(0.8));
    }
  }

  String baseURL = 'http://mrmodh11.pythonanywhere.com/';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AColor.background,
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: InkWell(
              onTap: () {},
              child: const Icon(
                Icons.logout,
              ),
            ),
          ),
        ],
        backgroundColor: AColor.themeColor,
        centerTitle: true,
        title: const Text('Images'),
      ),
      body: SingleChildScrollView(
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Container(
            color: Colors.transparent,
            padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
            child: Column(
              children: [
                TextField(
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                  ),
                  cursorColor: AColor.themeColor,
                  maxLength: 2,
                  controller: searchController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    hintText: 'how many images?',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: const BorderSide(
                          width: 2, color: AColor.grey), //<-- SEE HERE
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide:
                          const BorderSide(width: 2, color: AColor.themeColor),
                    ),
                    prefixIcon: const Icon(
                      Icons.search_rounded,
                      color: AColor.themeColor,
                    ),
                    counter: const SizedBox(),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.03,
                ),
                Center(
                  child: InkWell(
                    onTap: () {},
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.06,
                      width: MediaQuery.of(context).size.width * 0.35,
                      decoration: BoxDecoration(
                        color: AColor.themeColor,
                        borderRadius: BorderRadius.circular(19),
                      ),
                      child: const Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Display',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AColor.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // SizedBox(
                //   height: 100,
                //   width: 50,
                //   child: ListView.builder(
                //       itemCount: allImages.length,
                //       itemBuilder: (BuildContext context, int index) {
                //         return Card(
                //           shape: RoundedRectangleBorder(
                //             side: BorderSide(
                //               width: 1,
                //             ),
                //             borderRadius: BorderRadius.circular(18),
                //           ),
                //           elevation: 0.0,
                //           child: Image.network(baseURL +
                //               allImages[index].product_image.toString()),
                //         );
                //       }),
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
