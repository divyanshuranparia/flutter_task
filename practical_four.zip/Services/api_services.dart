import '../Model/image_model.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class ApiServices {
  Future<ImageModel> getData() async {
    var url = Uri.parse("http://mrmodh11.pythonanywhere.com/getProductImages");
    var result = await http.get(url);
    if (result.statusCode == 200) {
      final data = convert.jsonDecode(result.body);

      ImageModel getImageModel = ImageModel.fromJson(data);
      return getImageModel;
    } else {
      throw result.body;
    }
  }
}
