class ImageModel {
  String status;
  String message;
  List<Data> data;

  ImageModel({
    required this.status,
    required this.message,
    required this.data,
  });

  factory ImageModel.fromJson(Map<String, dynamic> json) {
    return ImageModel(
        message: json['message'],
        status: json['status'].toString(),
        data: (json['data'] as List).map((e) => Data.fromJson(e)).toList());
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'status': status,
      'data': data.map((e) => e.toJson()).toList(),
    };
  }
}

class Data {
  int? id;
  String? product_image;
  int? product_id;

  Data({
    this.id,
    this.product_image,
    this.product_id,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    product_image = json['product_image'];
    product_id = json['product_id'];
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'product_image': product_image,
        'product_id': product_id,
      };
}
