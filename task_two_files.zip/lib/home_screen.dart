import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final myImageAndCaption = [
    [
      "https://is1-ssl.mzstatic.com/image/thumb/Purple123/v4/0e/09/c4/0e09c462-c0cd-0a6c-d748-ea69b70442b7/source/256x256bb.jpg",
      "Top Songs heloafdasfdasfooooooooo"
    ],
    [
      "https://is1-ssl.mzstatic.com/image/thumb/Purple71/v4/d1/ba/85/d1ba8582-972e-7e02-6f3b-cc47adfc055f/source/256x256bb.jpg",
      "MJ Hits"
    ],
    [
      "https://c-cl.cdn.smule.com/rs-s78/arr/30/d7/5a82d9ae-9589-443c-b950-25c139abae89_256.jpg",
      "Smile"
    ],
    [
      "https://images.genius.com/af067ceaade20726f2b85176ff8dc6e8.256x256x1.jpg",
      "Rock Band"
    ],
    [
      "https://c-cl.cdn.smule.com/rs-s78/arr/f5/4e/27b764f1-91f2-41e7-934a-5bedf8b1751a.jpg",
      "Kishore"
    ],
    [
      "https://c-cl.cdn.smule.com/rs-s80/arr/56/f6/798ae822-373f-402a-a010-f7c60d0fd214.jpg",
      "Rafi"
    ],
  ];

  final myListImg = [
    "https://c.ndtvimg.com/2021-03/6kl5pk58_farhans-toofan_625x300_10_March_21.jpg",
    "https://c-cl.cdn.smule.com/rs-s95/arr/44/ec/a14c9db3-f454-4a86-80f0-ac9d42f6e87c_256.jpg",
    "https://c-cl.cdn.smule.com/rs-s-sf-4/arr/5e/ac/80498fa2-60ab-4c61-bf43-61b3df15f546.jpg",
    "https://c-cl.cdn.smule.com/rs-s92/arr/35/61/65d550a8-6d4e-4837-a067-c65b9e548ad7.jpg",
  ];

  final myListTitle = [
    "Toooofan",
    "Gully Boy",
    "Ae Dil Hai Mushkil",
    "Bajirao Mastani",
  ];

  final myListDesc = [
    "Dekh Toofan Aaya Hai",
    "Apna Time Aayega",
    "Ae Dil Hai Mushkil (Title Track)",
    "Malhari",
  ];

  Widget creatAppBar(String message) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        title: Text(
          message,
          style: GoogleFonts.sarabun(
            fontSize: 25,
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.notifications,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () {
              // do something
            },
          ),
          IconButton(
            icon: Icon(
              Icons.history_outlined,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(
              Icons.settings,
              color: Colors.white,
              size: 30,
            ),
            onPressed: () {},
          )
        ],
      ),
    );
  }

  Widget creatGrid() {
    return Container(
      padding: EdgeInsets.only(left: 13, right: 13),
      height: 270,
      child: GridView.count(
        childAspectRatio: 5 / 2,
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        children: [
          ...myImageAndCaption.map(
            (i) => Container(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  // Image.network(
                  //   i.first,
                  //   fit: BoxFit.cover,
                  // ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: CachedNetworkImage(
                      imageUrl: i.first,
                      fit: BoxFit.cover,
                    ),
                    // Image.network(
                    //   i.first,
                    //   fit: BoxFit.cover,
                    // ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0, right: 5.0),
                      child: Text(
                        i.last,
                        style: GoogleFonts.sarabun(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget creatList(String lable) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(13.0),
          child: Text(
            lable,
            style: GoogleFonts.sarabun(
              fontWeight: FontWeight.w900,
              fontSize: 25,
              color: Colors.white,
            ),
          ),
        ),
        Container(
          height: 280,
          child: ListView.builder(
            //padding: EdgeInsets.only(left: 13),
            scrollDirection: Axis.horizontal,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.only(left: 13.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10.0),
                      child: CachedNetworkImage(
                        imageUrl: myListImg[index],
                        fit: BoxFit.cover,
                        height: 200,
                        width: 200,
                        // Image.network(
                        //   myListImg[index],
                        //   fit: BoxFit.cover,
                        //   height: 200,
                        //   width: 200,
                        //
                      ),
                    ),
                    Text(
                      myListTitle[index],
                      style: GoogleFonts.sarabun(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w400),
                    ),
                    Text(
                      myListDesc[index],
                      style: GoogleFonts.sarabun(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w400),
                    ),
                  ],
                ),
              );
            },
            itemCount: myListImg.length,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  creatAppBar('Greetings'),
                  creatGrid(),
                  SizedBox(
                    height: 10,
                  ),
                  creatList('Jump back in'),
                  creatList('Recently Played'),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 56.0),
              child: Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  padding: const EdgeInsets.only(
                      left: 15.0, bottom: 10.0, right: 13.0),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  height: 65,
                  child: miniPlayer(),
                ),
              ),
            ),
          ],
        ),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            stops: [0.05, 0.5],
            colors: [Colors.purpleAccent, Colors.black],
          ),
        ),
      ),
      // bottomNavigationBar: Padding(
      //   padding: const EdgeInsets.only(bottom: 8.0),
      //   child: BottomNavigationBar(
      //     unselectedItemColor: Colors.white70,
      //     selectedItemColor: Colors.white,
      //     backgroundColor: Colors.transparent,
      //     items: [
      //       BottomNavigationBarItem(
      //         icon: Icon(Icons.home_filled),
      //         label: 'Home',
      //       ),
      //       BottomNavigationBarItem(
      //         icon: Icon(Icons.search_rounded),
      //         label: 'Search',
      //       ),
      //       BottomNavigationBarItem(
      //         icon: Icon(Icons.library_music_outlined),
      //         label: 'Library',
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  Widget miniPlayer() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
              imageUrl:
                  ('https://c-cl.cdn.smule.com/rs-s95/arr/44/ec/a14c9db3-f454-4a86-80f0-ac9d42f6e87c_256.jpg'),
              fit: BoxFit.cover,
            ),
            // Image.network(
            //     "https://c-cl.cdn.smule.com/rs-s95/arr/44/ec/a14c9db3-f454-4a86-80f0-ac9d42f6e87c_256.jpg"),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    "Apna Time Aayega • Div",
                    style: GoogleFonts.sarabun(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 3.0),
                  child: Row(
                    children: [
                      Icon(
                        Icons.bluetooth_outlined,
                        color: Color(0XFF1FDF64),
                        size: 14,
                      ),
                      Text(
                        "Boult Audio Airbass",
                        style: GoogleFonts.sarabun(
                          color: Color(0XFF1FDF64),
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Image.asset(
                    'assets/images/headphones.png',
                    height: 25,
                    color: Color(0XFF1FDF64),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Image.asset(
                      'assets/images/heart.png',
                      color: Colors.white,
                      height: 25,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Image.asset(
                      'assets/images/play.png',
                      color: Colors.white,
                      height: 25,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// bottomNavigationBar: Padding(
//   padding: const EdgeInsets.only(bottom: 8.0),
//   child: BottomNavigationBar(
//     unselectedItemColor: Colors.white70,
//     selectedItemColor: Colors.white,
//     backgroundColor: Colors.transparent,
//     items: [
//       BottomNavigationBarItem(
//         icon: Icon(Icons.home_filled),
//         label: 'Home',
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(Icons.search_rounded),
//         label: 'Search',
//       ),
//       BottomNavigationBarItem(
//         icon: Icon(Icons.library_music_outlined),
//         label: 'Library',
//       ),
//     ],
//   ),
// ),
